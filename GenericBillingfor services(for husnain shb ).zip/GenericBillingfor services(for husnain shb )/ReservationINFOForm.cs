﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class ReservationINFOForm : Form
    {
        public ReservationINFOForm()
        {
            InitializeComponent();
        }

        private void ReservationView_list_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (ReservationView_list.CurrentRow.Cells[0].Value != null && ReservationView_list.CurrentRow.Cells[1].Value != null && ReservationView_list.CurrentRow.Cells[2].Value != null && ReservationView_list.CurrentRow.Cells[3].Value != null && ReservationView_list.CurrentRow.Cells[4].Value != null && ReservationView_list.CurrentRow.Cells[5].Value != null)
                {
                    using (RoomDataSetTableAdapters.AdvanceReservationTableAdapter advance = new RoomDataSetTableAdapters.AdvanceReservationTableAdapter())
                    {
                        advance.Insert(ReservationView_list.CurrentRow.Cells[0].Value.ToString(), dateTimePickerforback.Value, ReservationView_list.CurrentRow.Cells[1].Value.ToString(), ReservationView_list.CurrentRow.Cells[2].Value.ToString(), ReservationView_list.CurrentRow.Cells[3].Value.ToString(), ReservationView_list.CurrentRow.Cells[4].Value.ToString(), ReservationView_list.CurrentRow.Cells[5].Value.ToString());
                        MessageBox.Show("ok");
                    }
                }

            }
            catch
            {

            }
        }

        private void Reseult_button_Click(object sender, EventArgs e)
        {
          //  int total = 0;
            using (RoomDataSetTableAdapters.AdvanceReservationTableAdapter employee = new RoomDataSetTableAdapters.AdvanceReservationTableAdapter())
            {
                string fDate = FromdateTime.Text;
                string tDate = TodateTime.Text;


                DateTime foDate = Convert.ToDateTime(fDate);
                DateTime toDate = Convert.ToDateTime(tDate);

                string from = foDate.ToString("yyyy-MM-dd");
                string to = toDate.ToString("yyyy-MM-dd");
                DataTable employeedt = employee.GetDataByDate(from, to);
                ReservationView_list.Rows.Clear();
                ReservationView_list.AllowUserToAddRows = false;
                ReservationView_list.ReadOnly = true;
                for (int i = 0; i < employeedt.Rows.Count; i++)
                {
                    ReservationView_list.Rows.Add(employeedt.Rows[i][1].ToString(), employeedt.Rows[i][3].ToString(), employeedt.Rows[i][4].ToString(), employeedt.Rows[i][5].ToString(), employeedt.Rows[i][6].ToString(), employeedt.Rows[i][7].ToString());
                }
                //for (int i = 0; i < ReservationView_list.Rows.Count; i++)
                //{
                //    if (ReservationView_list.Rows[i].Cells[2].Value != null)
                //    {
                //        total = total + int.Parse(ReservationView_list.Rows[i].Cells[2].Value.ToString());
                //    }
                //}
                //TotalValueoflist.Text = total.ToString();
            //    total = 0;
            }
        }

        private void ReservationINFOForm_Load(object sender, EventArgs e)
        {

            ReservationView_list.AllowUserToAddRows = true;
            ReservationView_list.ReadOnly = false;
        }

        private void Resetbutton_Click(object sender, EventArgs e)
        {
           

        }

        private void Free_Room_button_Click(object sender, EventArgs e)
        {
            ReservationINFOForm_Load(this, null);
            ReservationView_list.Rows.Clear();
            //TotalValueoflist.Text = "";
        }

        private void ReservationView_list_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
           
        }

        private void ReservationView_list_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete && ReservationView_list.ReadOnly == true && ReservationView_list.CurrentRow!=null)
            {
                using (RoomDataSetTableAdapters.AdvanceReservationTableAdapter ad = new RoomDataSetTableAdapters.AdvanceReservationTableAdapter())
                {
                    ReservationView_list.AllowUserToDeleteRows = true;
                    //  DataTable dt = ad.GetDataByPhoneNO();
                    ad.DeleteQuery(ReservationView_list.CurrentRow.Cells[1].Value.ToString());
                   
                }
            }
        }

        private void ReservationView_list_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            if (ReservationView_list.CurrentRow != null && ReservationView_list.ReadOnly==true)
            {
                UpdateAdvanceReservationForm update = new UpdateAdvanceReservationForm(ReservationView_list.CurrentRow.Cells[1].Value.ToString());
                update.Show();
            }
        }
    }
}
