﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
  public  class SaleReportByDateClass
    {
        public DateTime InvoiceDate { get; set; }
        public int InvoiceNo { get; set; }
        public int RoomNO { get; set; }
        public int Total { get; set; }
    }
}
