﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class ItemForm : Form
    {

        DataTable itemdt;

        //  public static = new DataTable();
        int RoomID;
        int NUM;
        //   List<string> itemName = new List<string>();
        public ItemForm(int roomId, int num, DataTable updatedt)
        {

            InitializeComponent();

            this.itemdt = updatedt;
            this.RoomID = roomId;
            this.NUM = num;
        }

        private void NewCategorybutton_Click(object sender, EventArgs e)
        {
            //if (CategoryNameTxt.Text != "")
            //{
            //    using (BillingDatabaseDataSetTableAdapters.CategoryTableAdapter cate = new BillingDatabaseDataSetTableAdapters.CategoryTableAdapter())
            //    {
            //        cate.Insert(CategoryNameTxt.Text);
            //        MessageBox.Show("Successfully Added");
            //        CategoryNameTxt.Text = "";
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Must Enter Category Name");
            //}
        }

        private void GenerateItemsList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int qty = 0;
                int price = 0;
                int total = 0;
                if (GenerateItemsList.CurrentRow.Cells[1].Value != null && GenerateItemsList.CurrentRow.Cells[2].Value != null)
                {
                    qty = int.Parse((GenerateItemsList.CurrentRow.Cells[2].Value).ToString());
                    price = int.Parse(GenerateItemsList.CurrentRow.Cells[1].Value.ToString());
                }
                GenerateItemsList.CurrentRow.Cells[3].Value = qty * price;
                for (int i = 0; i < GenerateItemsList.Rows.Count - 1; i++)
                {
                    if (GenerateItemsList.Rows[i].Cells[3].Value != null)
                    {
                        total = total + int.Parse(GenerateItemsList.Rows[i].Cells[3].Value.ToString());
                    }
                }
                TotalValueoflist.Text = total.ToString();

                total = 0;
            }
            catch
            {
                MessageBox.Show("Must be number");
            }
        }

        private void Submit_Items_Recoed_Click(object sender, EventArgs e)
        {
            //using (RoomDataSetTableAdapters.ServicesTableAdapter it = new RoomDataSetTableAdapters.ServicesTableAdapter())
            //{
            //    for (int i = 0; i <GenerateItemsList.Rows.Count-1; i++)
            //    {
            //      //  it.Insert(GenerateItemsList.Rows[i].Cells[0].Value.ToString(), int.Parse(GenerateItemsList.Rows[i].Cells[1].Value.ToString()), int.Parse(GenerateItemsList.Rows[i].Cells[2].Value.ToString()), int.Parse(GenerateItemsList.Rows[i].Cells[3].Value.ToString()));
            //        //gridviwData.Rows[i][0] = GenerateItemsList.Rows[i].Cells[0].Value;
            //        //gridviwData.Rows[i][1] = GenerateItemsList.Rows[i].Cells[1].Value.ToString();
            //        //gridviwData.Rows[i][2] = GenerateItemsList.Rows[i].Cells[2].Value.ToString();
            //        //gridviwData.Rows[i][3] = GenerateItemsList.Rows[i].Cells[3].Value.ToString();



            //    }
            //}
            //using (RoomDataSetTableAdapters.InvoiceTableAdapter dt = new RoomDataSetTableAdapters.InvoiceTableAdapter()) 
            //{
            //    using (RoomDataSetTableAdapters.ServicesTableAdapter it = new RoomDataSetTableAdapters.ServicesTableAdapter())
            //    {
            //        DataTable name;
            //        for (int j = 0; j < GenerateItemsList.Rows.Count; j++)
            //        {
            //             name = it.GetDataByName(GenerateItemsList.Rows[j].Cells[0].Value.ToString());
            //            dt.Insert(NUM, int.Parse(name.Rows[0][0].ToString()), int.Parse(GenerateItemsList.Rows[j].Cells[1].Value.ToString()), int.Parse(GenerateItemsList.Rows[j].Cells[2].Value.ToString()), int.Parse(GenerateItemsList.Rows[j].Cells[3].Value.ToString()));
            //        }
            //    }
            //}

            // TotalValueoflist.Text;
            AddCustomerForm form1 = (AddCustomerForm)Application.OpenForms["AddCustomerForm"];
            form1.Generate = GenerateItemsList;
            form1.SetValueForText1 = TotalValueoflist.Text;
            this.Hide();
            //  SetValueForText1 = TotalValueoflist.Text;



        }

        private void ItemForm_Load(object sender, EventArgs e)
        {
            if (RoomID == 0 && NUM == 0)
            {
                int total = 0;
                if (itemdt.Rows.Count>0)
                {
                    Submit_Items_Recoed.Visible = false;
                    Update_button.Visible = true;
                }
                else
                {
                    Submit_Items_Recoed.Visible = true;
                    Update_button.Visible = false;
                }

                for (int z = 0; z < itemdt.Rows.Count; z++)
                {
                    // itemName.Add(itemdt.Rows[z][5].ToString());
                    hiddendataGridView.Rows.Add(itemdt.Rows[z][1].ToString());
                    GenerateItemsList.Rows.Add(itemdt.Rows[z][5].ToString(), itemdt.Rows[z][2].ToString(), itemdt.Rows[z][3].ToString(), itemdt.Rows[z][4].ToString());
                    //  GenerateItemsList_CellEndEdit(this, null);
                }

                for (int i = 0; i < GenerateItemsList.Rows.Count - 1; i++)
                {
                    if (GenerateItemsList.Rows[i].Cells[3].Value != null)
                    {
                        total = total + int.Parse(GenerateItemsList.Rows[i].Cells[3].Value.ToString());
                    }
                }
                //AddCustomerForm form1 = (AddCustomerForm)Application.OpenForms["AddCustomerForm"];
                TotalValueoflist.Text = total.ToString();
                
                total = 0;

            }
            else
            {
                Submit_Items_Recoed.Visible = true;
                Update_button.Visible = false;
            }
        }

        private void Update_button_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.InvoiceTableAdapter ser = new RoomDataSetTableAdapters.InvoiceTableAdapter())
            {
                using (RoomDataSetTableAdapters.InvoiceTableAdapter invoice = new RoomDataSetTableAdapters.InvoiceTableAdapter())
                {
                    // 
                    if (GenerateItemsList.Rows.Count - 1 == itemdt.Rows.Count)
                    {

                        for (int x = 0; x < GenerateItemsList.Rows.Count - 1; x++)
                        {

                            //    DataTable dtserviceid = invoice.GetDataByServiceName(itemName[x]);
                            ser.Updateforitemrecord(GenerateItemsList.Rows[x].Cells[0].Value.ToString(), int.Parse(GenerateItemsList.Rows[x].Cells[1].Value.ToString()), int.Parse(GenerateItemsList.Rows[x].Cells[2].Value.ToString()), int.Parse(GenerateItemsList.Rows[x].Cells[3].Value.ToString()), int.Parse(itemdt.Rows[0][0].ToString()), int.Parse(hiddendataGridView.Rows[x].Cells[0].Value.ToString()));

                        }

                    }
                    else
                    {


                        //int check = (GenerateItemsList.Rows.Count - 1) - itemdt.Rows.Count;
                        for (int x = 0; x < itemdt.Rows.Count; x++)
                        {

                            //  DataTable dtserviceid = invoice.GetDataByServiceName(itemName[x]);



                            ser.Updateforitemrecord(GenerateItemsList.Rows[x].Cells[0].Value.ToString(), int.Parse(GenerateItemsList.Rows[x].Cells[1].Value.ToString()), int.Parse(GenerateItemsList.Rows[x].Cells[2].Value.ToString()), int.Parse(GenerateItemsList.Rows[x].Cells[3].Value.ToString()), int.Parse(itemdt.Rows[0][0].ToString()), int.Parse(hiddendataGridView.Rows[x].Cells[0].Value.ToString()));

                        }


                        for (int x = itemdt.Rows.Count; x < GenerateItemsList.Rows.Count - 1; x++)
                        {
                            ser.Insert(int.Parse(itemdt.Rows[0][0].ToString()), GenerateItemsList.Rows[x].Cells[0].Value.ToString(), int.Parse(GenerateItemsList.Rows[x].Cells[1].Value.ToString()), int.Parse(GenerateItemsList.Rows[x].Cells[2].Value.ToString()), int.Parse(GenerateItemsList.Rows[x].Cells[3].Value.ToString()));
                        }


                    }
                    //else
                    //{
                    //    for (int x = itemdt.Rows.Count; x < GenerateItemsList.Rows.Count - 1; x++)
                    //    {
                    //        ser.Insert(int.Parse(itemdt.Rows[0][0].ToString()), GenerateItemsList.Rows[x].Cells[0].Value.ToString(), int.Parse(GenerateItemsList.Rows[x].Cells[1].Value.ToString()), int.Parse(GenerateItemsList.Rows[x].Cells[2].Value.ToString()), int.Parse(GenerateItemsList.Rows[x].Cells[3].Value.ToString()));
                    //    }
                    //}
                }
                AddCustomerForm form1 = (AddCustomerForm)Application.OpenForms["AddCustomerForm"];
                form1.Generate = GenerateItemsList;
                form1.SetValueForText1 = TotalValueoflist.Text;
                this.Hide();
            }
        }

        private void ItemForm_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void ItemForm_KeyUp(object sender, KeyEventArgs e)
        {
           
        }

        private void GenerateItemsList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (GenerateItemsList.CurrentRow != null)
                {
                    int total = 0;
                    string message = "Are you sure you want to delete this Item?";
                    string title = "Free Room";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result = MessageBox.Show(message, title, buttons);

                    if (result == DialogResult.Yes)
                    {
                        using (RoomDataSetTableAdapters.InvoiceTableAdapter roo = new RoomDataSetTableAdapters.InvoiceTableAdapter())
                        {
                            DataTable dt = roo.GetDataByServiceName(GenerateItemsList.CurrentRow.Cells[0].Value.ToString());

                            if (dt.Rows.Count>0)
                            {
                                roo.DeleteQueryforservicename(GenerateItemsList.CurrentRow.Cells[0].Value.ToString());


                                GenerateItemsList.Rows.Clear();
                                DataTable allrows = roo.GetDataByReservationID(int.Parse(dt.Rows[0][0].ToString()));
                                for (int i = 0; i < allrows.Rows.Count; i++)
                                {
                                    total = total + int.Parse(allrows.Rows[i][4].ToString());
                                }

                                //using (RoomDataSetTableAdapters.ReservationTableAdapter room = new RoomDataSetTableAdapters.ReservationTableAdapter())
                                //{
                                //  DataTable data=  room.GetDataByReservationID(int.Parse(dt.Rows[0][0].ToString()));
                                AddCustomerForm form1 = (AddCustomerForm)Application.OpenForms["AddCustomerForm"];

                                this.Hide();

                                // form1.Hide();

                                //  AddCustomerForm add = new AddCustomerForm(, int.Parse(data.Rows[0][13].ToString()), null);
                                form1.SetValueForText1 = total.ToString();
                                //form1.Hide();
                                //                                add.Show();

                                // form AddCustomerForm_Load

                                //  ItemForm_Load(this, null);


                                total = 0;
                            }
                          
                        }

                    } }
                }
            }
        }
    }

