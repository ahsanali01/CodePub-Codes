﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
namespace WindowsFormsApplication1
{
    public partial class ReportForm : Form
    {
      //  DataTable DTTABLE;
        int ROOMID;
        public ReportForm( int roomid)
        {
            InitializeComponent();
          //  this.DTTABLE=dtdata;
            this.ROOMID = roomid;
           
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'testDataSet2.Invoice' table. You can move, or remove it, as needed.
            using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
            {
                using (RoomDataSetTableAdapters.RoomTableAdapter room = new RoomDataSetTableAdapters.RoomTableAdapter())
                {
                    DataTable dt = reser.GetDataByRoomIDReserved(ROOMID);
                    DataTable roomno = room.GetDataByRoomID(ROOMID);

                    using (RoomDataSetTableAdapters.InvoiceTableAdapter purchaseitem = new RoomDataSetTableAdapters.InvoiceTableAdapter())
                    {
                        DataTable itemdetail=purchaseitem.GetDataByReservationID(int.Parse(dt.Rows[0][0].ToString()));
                        List<GridViewClass> gridclass = new List<GridViewClass>();
                       
                        for(int i=0; i<itemdetail.Rows.Count; i++)
                        {
                            GridViewClass grid = new GridViewClass();
                            grid.itemName = itemdetail.Rows[i][5].ToString();
                            grid.price = long.Parse(itemdetail.Rows[i][2].ToString());
                            grid.Qty= long.Parse(itemdetail.Rows[i][3].ToString());
                            grid.Total= long.Parse(itemdetail.Rows[i][4].ToString());
                            gridclass.Add(grid);
                        }
                    


                        form1BindingSource.DataSource = gridclass;
                    }
                    ReportParameter[] para = new ReportParameter[] {


                  new ReportParameter("Members","Member(s): " +dt.Rows[0][5].ToString()),
                 //  new ReportParameter("Members","Member(s): " +dt.Rows[0][5].ToString()),

                  new ReportParameter("invoiceNo","Invoice: " + dt.Rows[0][6].ToString()),
                  new ReportParameter("Date",""+dt.Rows[0][7].ToString()),
                  new ReportParameter("Rent","Rent: " +dt.Rows[0][8].ToString()),
                   new ReportParameter("total",""+dt.Rows[0][16].ToString()),
                    new ReportParameter("discount",""+dt.Rows[0][9].ToString()),
                    new ReportParameter("CustomerName","Customer Name: " +dt.Rows[0][2].ToString()),
                    new ReportParameter("RoomNO","Room No: " +roomno.Rows[0][1].ToString()),
                     new ReportParameter("OtherCharges","Other Charges: " +dt.Rows[0][14].ToString()),

            };
                    this.reportViewer1.LocalReport.SetParameters(para);
                    // this.reportViewer1.Width = 75;
                    this.reportViewer1.LocalReport.Refresh();


                    this.reportViewer1.RefreshReport();
                }
            }
        }
        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void reportViewer1_Load_1(object sender, EventArgs e)
        {
           reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
           // reportViewer1.Print(paperSettings, printerName, PageRange.All)
           // public event ReportPrintEventHandler PrintingBegin;
        }
    }
}
