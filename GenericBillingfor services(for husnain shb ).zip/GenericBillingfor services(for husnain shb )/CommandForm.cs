﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class CommandForm : Form
    {
        int INVOICE = 0;
        public CommandForm(int invoice)
        {
            InitializeComponent();
            this.INVOICE = invoice;
        }

        private void Check_button_Click(object sender, EventArgs e)
        {
            if (Coomand_textBox.Text == "git_clone--ssh://git@github.com/[username]/[repository-name].git")
            {
                

                    using (RoomDataSetTableAdapters.ReservationTableAdapter iteminvoice = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dtreservation = iteminvoice.GetDataByReservationNo(INVOICE);
                        AddCustomerForm cust = new AddCustomerForm(dtreservation, int.Parse(dtreservation.Rows[0][13].ToString()), "buttoncheck");
                        cust.Show();
                    }
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong Command");
            }
        }
    }
}
