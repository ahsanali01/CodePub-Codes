﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class PurchaseInvoiceForm : Form
    {
        DataTable UpdateDATA;
        int INVOICEID;
        int counter=0;
        public PurchaseInvoiceForm(DataTable updatedata, int invoiceid)
        {
            InitializeComponent();
            this.UpdateDATA = updatedata;
            this.INVOICEID = invoiceid;
        }

        private void Purchasedatagridview_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int qty = 0;
                int price = 0;
                int total = 0;
                if (Purchasedatagridview.CurrentRow.Cells[1].Value != null && Purchasedatagridview.CurrentRow.Cells[2].Value != null)
                {
                    qty = int.Parse((Purchasedatagridview.CurrentRow.Cells[2].Value).ToString());
                    price = int.Parse(Purchasedatagridview.CurrentRow.Cells[1].Value.ToString());
                }
                Purchasedatagridview.CurrentRow.Cells[3].Value = qty * price;
                for (int i = 0; i < Purchasedatagridview.Rows.Count - 1; i++)
                {
                    if (Purchasedatagridview.Rows[i].Cells[3].Value != null)
                    {
                        total = total + int.Parse(Purchasedatagridview.Rows[i].Cells[3].Value.ToString());
                    }
                }
                TotalpurchasetextBox.Text = total.ToString();
                SubTotalPurchasetextBox.Text = total.ToString();

                total = 0;

            }
            catch
            {
                MessageBox.Show("Must be number");
            }
        }

        private void Purchasedatagridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void PurchaseInvoiceForm_Load(object sender, EventArgs e)
        {
            TotalpurchasetextBox.Text = "0";
            SubTotalPurchasetextBox.Text = "0";
            DiscountPurchasetextBox.Text = "0";
            if (UpdateDATA != null && INVOICEID != 0)
            {
                MakePurchase_button.Visible = false;
                Update_Purchase_button.Visible = true;
             //   invoice_id_txt.ReadOnly = true;
                using (RoomDataSetTableAdapters.ItemTableAdapter ite = new RoomDataSetTableAdapters.ItemTableAdapter())
                {
                    for (int i = 0; i < UpdateDATA.Rows.Count; i++)
                    {
                        DataTable itemdet = ite.GetDataById(int.Parse(UpdateDATA.Rows[i][0].ToString()));
                        Purchasedatagridview.Rows.Add(itemdet.Rows[0][1].ToString(), itemdet.Rows[0][2].ToString(), UpdateDATA.Rows[i][3].ToString(), UpdateDATA.Rows[i][2].ToString());


                    }

                }
                using (RoomDataSetTableAdapters.purchaseInvoiceTableAdapter ite = new RoomDataSetTableAdapters.purchaseInvoiceTableAdapter())
                {
                    DataTable dte = ite.GetDataById(INVOICEID);
                    invoice_id_txt.Text = INVOICEID.ToString();
                   IDtextBox.Text = dte.Rows[0][0].ToString();
                    //   dateTimePicker1.Text =dte.Rows[0][2].ToString();
                    DiscountPurchasetextBox.Text = dte.Rows[0][3].ToString();
                    SubTotalPurchasetextBox.Text = dte.Rows[0][4].ToString();
                    TotalpurchasetextBox.Text = (int.Parse(DiscountPurchasetextBox.Text) + int.Parse(SubTotalPurchasetextBox.Text)).ToString();
                }

            }
            else
            {
                MakePurchase_button.Visible = true;
                Update_Purchase_button.Visible = false;
            }
        }

        private void DiscountPurchasetextBox_TextChanged(object sender, EventArgs e)
        {
            // Total_textBox.Text = (int.Parse(Rent_txt.Text) + int.Parse(Foodtextfortotal.Text) + int.Parse(other_textBox.Text)).ToString();

            //  double subPrice = 0;
            if (DiscountPurchasetextBox.Text != "")
            {

                int a = int.Parse(TotalpurchasetextBox.Text);
                int b = int.Parse(DiscountPurchasetextBox.Text);
                //double divi = / 100;
                //subPrice = double.Parse(Total_textBox.Text) * divi;
                int c = (a - b);
                SubTotalPurchasetextBox.Text = c.ToString();
                c = 0;
            }
            else
            {
                //Total_textBox.Text = (int.Parse(Rent_txt.Text) + int.Parse(Foodtextfortotal.Text) + int.Parse(other_textBox.Text)).ToString();
                SubTotalPurchasetextBox.Text = TotalpurchasetextBox.Text;
            }

        }

        private void MakePurchase_button_Click(object sender, EventArgs e)
        {
            if (Purchasedatagridview != null && invoice_id_txt.Text != "" && DiscountPurchasetextBox.Text != "")
            {
                using (RoomDataSetTableAdapters.ItemTableAdapter item = new RoomDataSetTableAdapters.ItemTableAdapter())
                {
                    using (RoomDataSetTableAdapters.purchaseInvoiceTableAdapter purchaseinvoive = new RoomDataSetTableAdapters.purchaseInvoiceTableAdapter())
                    {
                        using (RoomDataSetTableAdapters.itemListPurchaseTableAdapter itemPurchase = new RoomDataSetTableAdapters.itemListPurchaseTableAdapter())
                        {
                            for (int i = 0; i < Purchasedatagridview.Rows.Count - 1; i++)
                            {
                                item.Insert(Purchasedatagridview.Rows[i].Cells[0].Value.ToString(), long.Parse(Purchasedatagridview.Rows[i].Cells[1].Value.ToString()));
                            }
                            purchaseinvoive.Insert(int.Parse(invoice_id_txt.Text),dateTimePicker1.Value, int.Parse(DiscountPurchasetextBox.Text), int.Parse(SubTotalPurchasetextBox.Text));
                            for (int i = 0; i < Purchasedatagridview.Rows.Count - 1; i++)
                            {
                                DataTable itemid = item.GetDataByName(Purchasedatagridview.Rows[i].Cells[0].Value.ToString());
                                DataTable invoceid = purchaseinvoive.GetDataById(int.Parse(invoice_id_txt.Text));
                                itemPurchase.Insert(int.Parse(itemid.Rows[0][0].ToString()), int.Parse(invoceid.Rows[0][0].ToString()), int.Parse(Purchasedatagridview.Rows[i].Cells[3].Value.ToString()), Purchasedatagridview.Rows[i].Cells[2].Value.ToString());

                            }
                            MessageBox.Show("Purchase Added successfully");
                            invoice_id_txt.Text = "";
                            Purchasedatagridview.Rows.Clear();
                            TotalpurchasetextBox.Text = "0";
                            SubTotalPurchasetextBox.Text = "0";
                            DiscountPurchasetextBox.Text = "0";

                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Enter data in all field");
            }
        }

        private void Update_Purchase_button_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.ItemTableAdapter item = new RoomDataSetTableAdapters.ItemTableAdapter())
            {
                using (RoomDataSetTableAdapters.purchaseInvoiceTableAdapter purchasedetail = new RoomDataSetTableAdapters.purchaseInvoiceTableAdapter())
                {
                    using (RoomDataSetTableAdapters.itemListPurchaseTableAdapter purchaseitemdetail = new RoomDataSetTableAdapters.itemListPurchaseTableAdapter())
                    {
                        if (UpdateDATA.Rows.Count == Purchasedatagridview.Rows.Count - 1)
                        {
                            for (int i = 0; i < Purchasedatagridview.Rows.Count - 1; i++)
                            {
                                item.UpdateQueryofitem(Purchasedatagridview.Rows[i].Cells[0].Value.ToString(), long.Parse(Purchasedatagridview.Rows[i].Cells[1].Value.ToString()), int.Parse(UpdateDATA.Rows[i][0].ToString()));
                                purchaseitemdetail.UpdateQueryforpurchaseidanditemid(int.Parse(Purchasedatagridview.Rows[i].Cells[3].Value.ToString()), Purchasedatagridview.Rows[i].Cells[2].Value.ToString(),int.Parse(IDtextBox.Text), int.Parse(UpdateDATA.Rows[i][0].ToString()));
                            }
                           
                            
                        }
                        else
                        {
                            //int check = (Purchasedatagridview.Rows.Count - 1) - UpdateDATA.Rows.Count;
                            for (int i = 0; i < UpdateDATA.Rows.Count-counter; i++)
                            {
                                item.UpdateQueryofitem(Purchasedatagridview.Rows[i].Cells[0].Value.ToString(), long.Parse(Purchasedatagridview.Rows[i].Cells[1].Value.ToString()), int.Parse(UpdateDATA.Rows[i][0].ToString()));
                                purchaseitemdetail.UpdateQueryforpurchaseidanditemid(int.Parse(Purchasedatagridview.Rows[i].Cells[3].Value.ToString()), Purchasedatagridview.Rows[i].Cells[2].Value.ToString(), int.Parse(IDtextBox.Text), int.Parse(UpdateDATA.Rows[i][0].ToString()));
                            }
                            for (int i= UpdateDATA.Rows.Count+counter; i < Purchasedatagridview.Rows.Count - 1; i++)
                            {
                                item.Insert(Purchasedatagridview.Rows[i].Cells[0].Value.ToString(), long.Parse(Purchasedatagridview.Rows[i].Cells[1].Value.ToString()));
                               DataTable newitemid= item.GetDataByName(Purchasedatagridview.Rows[i].Cells[0].Value.ToString());
                                purchaseitemdetail.Insert(int.Parse(newitemid.Rows[0][0].ToString()),int.Parse(IDtextBox.Text), int.Parse(Purchasedatagridview.Rows[i].Cells[3].Value.ToString()), Purchasedatagridview.Rows[i].Cells[2].Value.ToString());
                            }
                        }
                        purchasedetail.UpdateQuarybypurchase(dateTimePicker1.Value, int.Parse(DiscountPurchasetextBox.Text) ,int.Parse(TotalpurchasetextBox.Text), int.Parse(invoice_id_txt.Text),int.Parse(IDtextBox.Text));
                        MessageBox.Show("Updted successfully");
                        BillDisplayForm form1 = (BillDisplayForm)Application.OpenForms["BillDisplayForm"];
                        
                        form1.BillDisplayForm_Load(this, null);
                        invoice_id_txt.Text = "";
                        Purchasedatagridview.Rows.Clear();
                        TotalpurchasetextBox.Text = "0";
                        SubTotalPurchasetextBox.Text = "0";
                        DiscountPurchasetextBox.Text = "0";
                    }
                }
            }
        }

        private void PurchaseInvoiceForm_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void Purchasedatagridview_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (Purchasedatagridview.CurrentRow != null && UpdateDATA != null)
                {
                    using (RoomDataSetTableAdapters.itemListPurchaseTableAdapter iteminvoice = new RoomDataSetTableAdapters.itemListPurchaseTableAdapter())
                    {
                        using (RoomDataSetTableAdapters.ItemTableAdapter item = new RoomDataSetTableAdapters.ItemTableAdapter())
                        {

                            DataTable itemID = item.GetDataByName(Purchasedatagridview.CurrentRow.Cells[0].Value.ToString());
                            iteminvoice.DeleteQuery(int.Parse(itemID.Rows[0][0].ToString()));
                            item.DeleteQuery(int.Parse(itemID.Rows[0][0].ToString()));
                            Purchasedatagridview_CellEndEdit(this, null);
                            Update_Purchase_button_Click(this, null);
                            counter++;
                            this.Hide();
                        }
                    }
                }
            }
        }
    }
}
