﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class billwiseForm : Form
    {
        public billwiseForm()
        {
            InitializeComponent();
        }

        private void billwiseForm_Load(object sender, EventArgs e)
        {



        }

        private void button_bill_Click(object sender, EventArgs e)
        {
            //    try
            //  {
            //using (BillingDatabaseDataSetTableAdapters.SalesInvoiceTableAdapter saletable = new BillingDatabaseDataSetTableAdapters.SalesInvoiceTableAdapter())
            //{
            //    using (BillingDatabaseDataSetTableAdapters.InvoiceTableAdapter invtable = new BillingDatabaseDataSetTableAdapters.InvoiceTableAdapter())
            //    {
            //        using (BillingDatabaseDataSetTableAdapters.CustomerTableAdapter custable = new BillingDatabaseDataSetTableAdapters.CustomerTableAdapter())
            //        {
            //            using (BillingDatabaseDataSetTableAdapters.ServicesTableAdapter itetable = new BillingDatabaseDataSetTableAdapters.ServicesTableAdapter())
            //            {
            //                using (BillingDatabaseDataSetTableAdapters.RoomTableAdapter Roomtable = new BillingDatabaseDataSetTableAdapters.RoomTableAdapter())
            //                {
            //                    DataTable dtsale = saletable.GetDataByInvoiveID(long.Parse(Searc_Invoice_textBox.Text));
            //                    DataTable dtinvoice = invtable.GetDatadetailByInvoice(long.Parse(Searc_Invoice_textBox.Text));

            //                    // DataTable dtsale = saletable.GetData();
            //                    List<paidClass> pai = new List<paidClass>();

            //                    for (int i = 0; i < dtinvoice.Rows.Count; i++)
            //                    {
            //                        paidClass paid = new paidClass();
            //                        DataTable dtitem = itetable.GetDataByitemID(long.Parse(dtinvoice.Rows[i][4].ToString()));
            //                        paid.Nameofitem = dtitem.Rows[0][1].ToString();
            //                        paid.Quantityofitem = long.Parse(dtinvoice.Rows[i][1].ToString());
            //                        paid.Priceofitem = long.Parse(dtinvoice.Rows[i][2].ToString());
            //                        paid.amount = long.Parse(dtinvoice.Rows[i][3].ToString());
            //                        pai.Add(paid);
            //                    }
            //                    DataTable custdt = custable.GetDataByID(int.Parse(dtsale.Rows[0][5].ToString()));
            //                    DataTable Roomdt = Roomtable.GetDataById(int.Parse(dtsale.Rows[0][4].ToString()));

            //                    paidClassBindingSource.DataSource = pai;
            //                    ReportParameter[] parameterofitem = new ReportParameter[] {

            //                 new ReportParameter("invoiceNo1","Invc#:"+dtsale.Rows[0][0].ToString()),
            //      new ReportParameter("Date1",""+dtsale.Rows[0][1].ToString()),

            //      new ReportParameter("subTotal1",""+dtsale.Rows[0][2].ToString()),
            //      new ReportParameter("total1",""+dtsale.Rows[0][2].ToString()),
            //      new ReportParameter("discount1",""+"0"),
            //       new ReportParameter("companyName1",""+"Your Company Name"),
            //       new ReportParameter("CustomerName1","Customer Name:  "+custdt.Rows[0][2].ToString()),
            //       new ReportParameter("RoomName1","Room Name:  "+Roomdt.Rows[0][2].ToString()),


            //};
            //                    this.reportViewer1.LocalReport.SetParameters(parameterofitem);
            //                    // this.reportViewer1.Width = 75;
            //                    this.reportViewer1.RefreshReport();
            //                }
            //            }
                    }
                    //   }
                    // catch (Exception)
                    //{
                    //  MessageBox.Show("!Invoice not exist");
                    //}
                

            
        

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
