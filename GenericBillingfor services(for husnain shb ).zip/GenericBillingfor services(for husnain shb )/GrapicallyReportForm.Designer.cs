﻿namespace WindowsFormsApplication1
{
    partial class GrapicallyReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.saleReportByDateClassBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.saleReportByDateClassBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.Grapicallybutton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TodateTime = new System.Windows.Forms.DateTimePicker();
            this.FromdateTime = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.saleReportByDateClassBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleReportByDateClassBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // saleReportByDateClassBindingSource1
            // 
            this.saleReportByDateClassBindingSource1.DataSource = typeof(WindowsFormsApplication1.SaleReportByDateClass);
            // 
            // reportViewer1
            // 
            this.reportViewer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.saleReportByDateClassBindingSource1;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication1.GrapicallyReport.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 40);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(906, 310);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load);
            // 
            // Grapicallybutton
            // 
            this.Grapicallybutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(226)))), ((int)(((byte)(118)))));
            this.Grapicallybutton.FlatAppearance.BorderSize = 0;
            this.Grapicallybutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Grapicallybutton.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Grapicallybutton.Location = new System.Drawing.Point(588, 9);
            this.Grapicallybutton.Name = "Grapicallybutton";
            this.Grapicallybutton.Size = new System.Drawing.Size(75, 23);
            this.Grapicallybutton.TabIndex = 10;
            this.Grapicallybutton.Text = "Get Result";
            this.Grapicallybutton.UseVisualStyleBackColor = false;
            this.Grapicallybutton.Click += new System.EventHandler(this.Grapicallybutton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(304, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "To:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "From:";
            // 
            // TodateTime
            // 
            this.TodateTime.CustomFormat = "";
            this.TodateTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.TodateTime.ImeMode = System.Windows.Forms.ImeMode.On;
            this.TodateTime.Location = new System.Drawing.Point(339, 10);
            this.TodateTime.Name = "TodateTime";
            this.TodateTime.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TodateTime.Size = new System.Drawing.Size(200, 20);
            this.TodateTime.TabIndex = 7;
            this.TodateTime.Value = new System.DateTime(2020, 10, 22, 0, 0, 0, 0);
            // 
            // FromdateTime
            // 
            this.FromdateTime.CustomFormat = "";
            this.FromdateTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.FromdateTime.Location = new System.Drawing.Point(67, 10);
            this.FromdateTime.Name = "FromdateTime";
            this.FromdateTime.Size = new System.Drawing.Size(200, 20);
            this.FromdateTime.TabIndex = 6;
            this.FromdateTime.Value = new System.DateTime(2020, 12, 23, 0, 0, 0, 0);
            // 
            // GrapicallyReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(906, 349);
            this.Controls.Add(this.Grapicallybutton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TodateTime);
            this.Controls.Add(this.FromdateTime);
            this.Controls.Add(this.reportViewer1);
            this.Name = "GrapicallyReportForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GrapicallyReportForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.GrapicallyReportForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.saleReportByDateClassBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleReportByDateClassBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource saleReportByDateClassBindingSource;
        private System.Windows.Forms.Button Grapicallybutton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker TodateTime;
        private System.Windows.Forms.DateTimePicker FromdateTime;
        private System.Windows.Forms.BindingSource saleReportByDateClassBindingSource1;
    }
}