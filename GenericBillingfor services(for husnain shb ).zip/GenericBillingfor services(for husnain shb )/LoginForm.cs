﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Loginbutton_Click(object sender, EventArgs e)
        {
            string conString = @"Data Source=localhost;port=3306;Initial Catalog=logindetails;User Id=root;";
            using (MySqlConnection con = new MySqlConnection(conString))
            {
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM loginprovider", con))
                {
                    cmd.CommandType = CommandType.Text;
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            if (dt.Rows.Count != 0)
                            {
                                if(UserNametextBox.Text==dt.Rows[0][1].ToString() && PasswordtextBox.Text== dt.Rows[0][2].ToString())
                                {
                                    if (dt.Rows[0][3].ToString() == "Deactive")
                                    {
                                        MessageBox.Show("Pay Your Monthly bill First");
                                    }
                                    else
                                    {
                                        Form1 f = new Form1();
                                        f.Show();

                                      
                                        PasswordtextBox.Text = "";
                                        Messageshowlabel.Visible = true;
                                        Messageshowlabel.Text = "You Login Successfully";

                                    }
                                }
                                else
                                {
                                    MessageBox.Show("UserName and Password is incorrect");
                                    PasswordtextBox.Text = "";
                                }
                            }
                           
                        }
                    }
                }
            }
        }
    }
}
