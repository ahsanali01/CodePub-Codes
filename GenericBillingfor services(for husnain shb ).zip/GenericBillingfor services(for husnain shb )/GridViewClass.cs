﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
   public class GridViewClass
    {
        public string itemName { get; set; }
        public long price { get; set; }
        public long Qty { get; set; }

        public long Total { get; set; }
    }
}
