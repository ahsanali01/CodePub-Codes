﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class paidClass
    {
        public string Nameofitem {get;set;} 
        public long  Quantityofitem { get; set; }
        public long Priceofitem { get; set; }
        public long amount { get; set; }
    }
}
