﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class UpdateAdvanceReservationForm : Form
    {
        string phone_no;
        public UpdateAdvanceReservationForm(string phoneno)
        {
            InitializeComponent();
            this.phone_no = phoneno;
        }

        private void UpdateAdvanceReservationForm_Load(object sender, EventArgs e)
        {
            if (phone_no != "")
            {
                using (RoomDataSetTableAdapters.AdvanceReservationTableAdapter ad = new RoomDataSetTableAdapters.AdvanceReservationTableAdapter())
                {
                    DataTable dt = ad.GetDataByPhoneNO(phone_no);
                    CustomerName.Text = dt.Rows[0][1].ToString();
                    PhoneNo.Text = dt.Rows[0][3].ToString();
                    RoomNo.Text = dt.Rows[0][4].ToString();
                    Rent.Text = dt.Rows[0][5].ToString();
                    Advance.Text = dt.Rows[0][6].ToString();
                    CO.Text = dt.Rows[0][7].ToString();
                }
            }
        }
        private void Update_button_Click(object sender, EventArgs e)
        {
                    using (RoomDataSetTableAdapters.AdvanceReservationTableAdapter ad = new RoomDataSetTableAdapters.AdvanceReservationTableAdapter())
            {
                DataTable dt = ad.GetDataByPhoneNO(phone_no);
                ad.UpdateQueryforReservationn(CustomerName.Text, PhoneNo.Text, RoomNo.Text, Rent.Text, Advance.Text, CO.Text, int.Parse(dt.Rows[0][0].ToString()));
                MessageBox.Show("Updated");
            }
        }
    }
}
