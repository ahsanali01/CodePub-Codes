﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class MontlysaleForm : Form
    {
        string companyname;
      int totalSale=0;
        List<SaleReportByDateClass> salereportlist = new List<SaleReportByDateClass>();
        public MontlysaleForm(string company)
        {
            this.companyname = company;
            InitializeComponent();
        }

        private void MontlysaleForm_Load(object sender, EventArgs e)
        {
            
           
        }


        private void GetresultByDatebutton_Click(object sender, EventArgs e)
        {
            salereportlist.Clear();
            using (RoomDataSetTableAdapters.ReservationTableAdapter invoice = new RoomDataSetTableAdapters.ReservationTableAdapter())
            {
                string fDate = FromdateTime.Text;
                string tDate = TodateTime.Text;


                DateTime foDate = Convert.ToDateTime(fDate);
                DateTime toDate = Convert.ToDateTime(tDate);

                string from = foDate.ToString("yyyy-MM-dd");
                string to = toDate.ToString("yyyy-MM-dd");

                // DateTime fromDate = Convert.ToDateTime(from);
                //    DateTime tooDate = Convert.ToDateTime(to);

                DataTable dt = new DataTable();
                dt = invoice.GetDataByDate(from, to);
                using (RoomDataSetTableAdapters.RoomTableAdapter room = new RoomDataSetTableAdapters.RoomTableAdapter())
                {
                    for (int j = 0; j < dt.Rows.Count; j++)
                    {
                       DataTable data = room.GetDataByRoomID(int.Parse(dt.Rows[j][13].ToString()));
                        SaleReportByDateClass sale = new SaleReportByDateClass();
                        sale.InvoiceDate = DateTime.Parse(dt.Rows[j][7].ToString());
                        sale.InvoiceNo = int.Parse(dt.Rows[j][6].ToString());
                        sale.RoomNO = int.Parse(data.Rows[0][1].ToString());
                        sale.Total= int.Parse(dt.Rows[j][16].ToString());
                        //        sale.Qty = long.Parse(dt.Rows[j][1].ToString());
                        //        sale.Total = long.Parse(dt.Rows[j][6].ToString());
                             totalSale = totalSale + int.Parse(dt.Rows[j][16].ToString());
                            salereportlist.Add(sale);
                        
                    }
                   
                     saleReportByDateClassBindingSource1.DataSource = salereportlist;
                 
                      ReportParameter[] para = new ReportParameter[] {


                          new ReportParameter("fromDate",""+FromdateTime.Text),

                          new ReportParameter("toDate",""+TodateTime.Text),
                         new ReportParameter("totalSale","Total Sale:"+totalSale),
                          new ReportParameter("companyName",""+companyname),


                    };
                    this.reportViewer1.LocalReport.SetParameters(para);
                    // this.reportViewer1.Width = 75;
                    this.reportViewer1.RefreshReport();
                    reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
                    //salereportlist.Clear();
                    totalSale = 0;
                }


            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TodateTime_ValueChanged(object sender, EventArgs e)
        {

        }

        private void FromdateTime_ValueChanged(object sender, EventArgs e)
        {

        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {
         
        }
    }
}
