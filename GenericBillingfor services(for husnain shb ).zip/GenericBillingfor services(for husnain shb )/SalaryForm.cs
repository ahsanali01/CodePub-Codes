﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class SalaryForm : Form
    {
        public SalaryForm()
        {
            InitializeComponent();
        }

        private void EmployeeView_list_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int Advance_Salary = 0;
                int Salary = 0;
                // int total = 0;
                if (EmployeeView_list.CurrentRow.Cells[1].Value != null && EmployeeView_list.CurrentRow.Cells[2].Value != null)
                {
                    Advance_Salary = int.Parse((EmployeeView_list.CurrentRow.Cells[2].Value).ToString());
                    Salary = int.Parse(EmployeeView_list.CurrentRow.Cells[1].Value.ToString());
                }
                EmployeeView_list.CurrentRow.Cells[3].Value = Salary - Advance_Salary;
                //  for (int i = 0; i < EmployeeView_list.Rows.Count - 1; i++)
                //  {
                //      if (EmployeeView_list.Rows[i].Cells[3].Value != null)
                //      {
                //          total = total + int.Parse(EmployeeView_list.Rows[i].Cells[3].Value.ToString());
                //      }
                //  }
                ////  TotalValueoflist.Text = total.ToString();

                // total = 0;
                using (RoomDataSetTableAdapters.EmployeeTableAdapter employee = new RoomDataSetTableAdapters.EmployeeTableAdapter())
                {
                    //   for (int i = 0; i < EmployeeView_list.Rows.Count-1; i++)
                    // {
                    employee.Insert(dateTimePickerforback.Value, EmployeeView_list.CurrentRow.Cells[0].Value.ToString(), int.Parse(EmployeeView_list.CurrentRow.Cells[1].Value.ToString()), int.Parse(EmployeeView_list.CurrentRow.Cells[2].Value.ToString()), int.Parse(EmployeeView_list.CurrentRow.Cells[3].Value.ToString()));
                    //}
                }
            }
            catch
            {
                //  MessageBox.Show("Must be number");
            }
        }

        private void Reseult_button_Click(object sender, EventArgs e)
        {
            int total = 0;
            using (RoomDataSetTableAdapters.EmployeeTableAdapter employee = new RoomDataSetTableAdapters.EmployeeTableAdapter())
            {
                string fDate = FromdateTime.Text;
                string tDate = TodateTime.Text;


                DateTime foDate = Convert.ToDateTime(fDate);
                DateTime toDate = Convert.ToDateTime(tDate);

                string from = foDate.ToString("yyyy-MM-dd");
                string to = toDate.ToString("yyyy-MM-dd");
                DataTable employeedt = employee.GetDataByDate(from, to);
                EmployeeView_list.Rows.Clear();
                EmployeeView_list.AllowUserToAddRows = false;
                EmployeeView_list.ReadOnly = true;
                for (int i = 0; i < employeedt.Rows.Count; i++)
                {
                    EmployeeView_list.Rows.Add(employeedt.Rows[i][2].ToString(), employeedt.Rows[i][3].ToString(), employeedt.Rows[i][4].ToString(), employeedt.Rows[i][5].ToString());
                }
                for (int i = 0; i < EmployeeView_list.Rows.Count; i++)
                {
                    if (EmployeeView_list.Rows[i].Cells[2].Value != null)
                    {
                        total = total + int.Parse(EmployeeView_list.Rows[i].Cells[2].Value.ToString());
                    }
                }
                TotalValueoflist.Text = total.ToString();
                total = 0;
            }
        }

        private void SalaryForm_Load(object sender, EventArgs e)
        {
            
            EmployeeView_list.AllowUserToAddRows = true;
            EmployeeView_list.ReadOnly = false;
        }

        private void Resetbutton_Click(object sender, EventArgs e)
        {
           
        }

        private void Free_Room_button_Click(object sender, EventArgs e)
        {
            SalaryForm_Load(this, null);
            EmployeeView_list.Rows.Clear();
            TotalValueoflist.Text = "";
        }
    }
}
