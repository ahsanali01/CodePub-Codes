﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
      //  int Roomid=0;
        public Form1()
        {


            InitializeComponent();


        }



        private void Add_Stock_Button(object sender, EventArgs e)
        {
           // AddStock add = new AddStock();
          //  add.Show();
        }

        private void Viewbutton_Click(object sender, EventArgs e)
        {
          //  ViewStock view = new ViewStock();
            //view.Show();


        }

        public void Form1_Load(object sender, EventArgs e)
        {
            int count = 0;
            Button btn = new Button();
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetData();

                Totalroom.Text=(dt.Rows.Count).ToString();
                for(int i=0;  i<dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][2].ToString() == "Free")
                    {
                        count++;
                    }
                }
                Freeroom.Text = count.ToString();
                occupaidroom.Text = (dt.Rows.Count - count ).ToString();
                if (dt.Rows[0][2].ToString() == "Free" && dt.Rows[0][0].ToString() == "54")
                {
                    button_room1.BackColor = Color.FromArgb(154, 210, 127);
                }
                else 
                {
                    button_room1.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[1][2].ToString() == "Free" && dt.Rows[1][0].ToString() == "55")
                {
                    buttonRoom2.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom2.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[2][2].ToString() == "Free" && dt.Rows[2][0].ToString() == "56")
                {
                    buttonRoom3.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom3.BackColor = Color.FromArgb(226, 125, 144);
                }

                if (dt.Rows[3][2].ToString() == "Free" && dt.Rows[3][0].ToString() == "57")
                {
                    buttonRoom4.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom4.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[4][2].ToString() == "Free" && dt.Rows[4][0].ToString() == "58")
                {
                    buttonRoom5.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom5.BackColor = Color.FromArgb(226, 125, 144);
                }

                if (dt.Rows[5][2].ToString() == "Free" && dt.Rows[5][0].ToString() == "59")
                {
                    buttonRoom6.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom6.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[6][2].ToString() == "Free" && dt.Rows[6][0].ToString() == "60")
                {
                    buttonRoom7.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom7.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[7][2].ToString() == "Free" && dt.Rows[7][0].ToString() == "61")
                {
                    buttonRoom8.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom8.BackColor = Color.FromArgb(226, 125, 144);
                }



           
                if (dt.Rows[8][2].ToString() == "Free" && dt.Rows[8][0].ToString() == "62")
                {
                    buttonRoom9.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom9.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[9][2].ToString() == "Free" && dt.Rows[9][0].ToString() == "63")
                {
                    buttonRoom10.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom10.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[10][2].ToString() == "Free" && dt.Rows[10][0].ToString() == "64")
                {
                    buttonRoom11.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom11.BackColor = Color.FromArgb(226, 125, 144);
                }

                if (dt.Rows[11][2].ToString() == "Free" && dt.Rows[11][0].ToString() == "65")
                {
                    buttonRoom12.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom12.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[12][2].ToString() == "Free" && dt.Rows[12][0].ToString() == "66")
                {
                    buttonRoom13.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom13.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[13][2].ToString() == "Free" && dt.Rows[13][0].ToString() == "67")
                {
                    buttonRoom14.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom14.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[14][2].ToString() == "Free" && dt.Rows[14][0].ToString() == "68")
                {
                    buttonRoom15.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom15.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[15][2].ToString() == "Free" && dt.Rows[15][0].ToString() == "69")
                {
                    buttonRoom16.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom16.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[16][2].ToString() == "Free" && dt.Rows[16][0].ToString() == "70")
                {
                    buttonRoom17.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom17.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[17][2].ToString() == "Free" && dt.Rows[17][0].ToString() == "71")
                {
                    buttonRoom18.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom18.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[18][2].ToString() == "Free" && dt.Rows[18][0].ToString() == "72")
                {
                    buttonRoom19.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom19.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[19][2].ToString() == "Free" && dt.Rows[19][0].ToString() == "73")
                {
                    buttonRoom20.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom20.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[20][2].ToString() == "Free" && dt.Rows[20][0].ToString() == "74")
                {
                    buttonRoom21.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom21.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[21][2].ToString() == "Free" && dt.Rows[21][0].ToString() == "75")
                {
                    buttonRoom22.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom22.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[22][2].ToString() == "Free" && dt.Rows[22][0].ToString() == "76")
                {
                    buttonRoom23.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom23.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[23][2].ToString() == "Free" && dt.Rows[23][0].ToString() == "77")
                {
                    buttonRoom24.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom24.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[24][2].ToString() == "Free" && dt.Rows[24][0].ToString() == "78")
                {
                    buttonRoom25.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom25.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[25][2].ToString() == "Free" && dt.Rows[25][0].ToString() == "79")
                {
                    buttonRoom26.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom26.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[26][2].ToString() == "Free" && dt.Rows[26][0].ToString() == "80")
                {
                    buttonRoom27.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom27.BackColor = Color.FromArgb(226, 125, 144);
                }

                if (dt.Rows[27][2].ToString() == "Free" && dt.Rows[27][0].ToString() == "81")
                {
                    buttonRoom28.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom28.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[28][2].ToString() == "Free" && dt.Rows[28][0].ToString() == "82")
                {
                    buttonRoom29.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom29.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[29][2].ToString() == "Free" && dt.Rows[29][0].ToString() == "83")
                {
                    buttonRoom30.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom30.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[30][2].ToString() == "Free" && dt.Rows[30][0].ToString() == "84")
                {
                    buttonRoom31.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom31.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[31][2].ToString() == "Free" && dt.Rows[31][0].ToString() == "85")
                {
                    buttonRoom32.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom32.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[32][2].ToString() == "Free" && dt.Rows[32][0].ToString() == "86")
                {
                    buttonRoom33.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom33.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[33][2].ToString() == "Free" && dt.Rows[33][0].ToString() == "87")
                {
                    buttonRoom34.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom34.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[34][2].ToString() == "Free" && dt.Rows[34][0].ToString() == "88")
                {
                    buttonRoom35.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom35.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[35][2].ToString() == "Free" && dt.Rows[35][0].ToString() == "89")
                {
                    buttonRoom36.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom36.BackColor = Color.FromArgb(226, 125, 144);
                }
                if (dt.Rows[36][2].ToString() == "Free" && dt.Rows[36][0].ToString() == "90")
                {
                    buttonRoom37.BackColor = Color.FromArgb(154, 210, 127);
                }
                else
                {
                    buttonRoom37.BackColor = Color.FromArgb(226, 125, 144);
                }
                //if (dt.Rows[37][2].ToString() == "Free" && dt.Rows[37][0].ToString() == "38")
                //{
                //    buttonRoom34.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom34.BackColor = Color.FromArgb(226, 125, 144);
                //}
                ////if (dt.Rows[38][2].ToString() == "Free" && dt.Rows[38][0].ToString() == "39")
                ////{
                ////    buttonRoom39.BackColor = Color.FromArgb(154, 210, 127);
                ////}
                ////else
                ////{
                ////    buttonRoom39.BackColor = Color.FromArgb(226, 125, 144);
                ////}
                //if (dt.Rows[39][2].ToString() == "Free" && dt.Rows[39][0].ToString() == "40")
                //{
                //    buttonRoom35.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom35.BackColor = Color.FromArgb(226, 125, 144);
                //}
                ////if (dt.Rows[40][2].ToString() == "Free" && dt.Rows[40][0].ToString() == "41")
                ////{
                ////    buttonRoom41.BackColor = Color.FromArgb(154, 210, 127);
                ////}
                ////else
                ////{
                ////    buttonRoom41.BackColor = Color.FromArgb(226, 125, 144);
                ////}
                //if (dt.Rows[41][2].ToString() == "Free" && dt.Rows[41][0].ToString() == "42")
                //{
                //    buttonRoom36.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom36.BackColor = Color.FromArgb(226, 125, 144);
                //}
                ////if (dt.Rows[42][2].ToString() == "Free" && dt.Rows[42][0].ToString() == "43")
                ////{
                ////    buttonRoom43.BackColor = Color.FromArgb(154, 210, 127);
                ////}
                ////else
                ////{
                ////    buttonRoom43.BackColor = Color.FromArgb(226, 125, 144);
                ////}
                //if (dt.Rows[43][2].ToString() == "Free" && dt.Rows[43][0].ToString() == "44")
                //{
                //    buttonRoom37.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom37.BackColor = Color.FromArgb(226, 125, 144);
                //}
                ////if (dt.Rows[44][2].ToString() == "Free" && dt.Rows[44][0].ToString() == "45")
                ////{
                ////    buttonRoom45.BackColor = Color.FromArgb(154, 210, 127);
                ////}
                //else
                //{
                //    buttonRoom45.BackColor = Color.FromArgb(226, 125, 144);
                //}
                //if (dt.Rows[45][2].ToString() == "Free" && dt.Rows[45][0].ToString() == "46")
                //{
                //    buttonRoom46.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom46.BackColor = Color.FromArgb(226, 125, 144);
                //}
                //if (dt.Rows[46][2].ToString() == "Free" && dt.Rows[46][0].ToString() == "47")
                //{
                //    buttonRoom47.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom47.BackColor = Color.FromArgb(226, 125, 144);
                //}
                //if (dt.Rows[47][2].ToString() == "Free" && dt.Rows[47][0].ToString() == "48")
                //{
                //    buttonRoom48.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom48.BackColor = Color.FromArgb(226, 125, 144);
                //}
                //if (dt.Rows[48][2].ToString() == "Free" && dt.Rows[48][0].ToString() == "49")
                //{
                //    buttonRoom49.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom49.BackColor = Color.FromArgb(226, 125, 144);
                //}
                //if (dt.Rows[49][2].ToString() == "Free" && dt.Rows[49][0].ToString() == "50")
                //{
                //    buttonRoom50.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom50.BackColor = Color.FromArgb(226, 125, 144);
                //}
                //if (dt.Rows[50][2].ToString() == "Free" && dt.Rows[50][0].ToString() == "51")
                //{
                //    buttonRoom51.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom51.BackColor = Color.FromArgb(226, 125, 144);
                //}
                //if (dt.Rows[51][2].ToString() == "Free" && dt.Rows[51][0].ToString() == "52")
                //{
                //    buttonRoom52.BackColor = Color.FromArgb(154, 210, 127);
                //}
                //else
                //{
                //    buttonRoom52.BackColor = Color.FromArgb(226, 125, 144);
                //}
            }


        }

        private void Additem_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {


        }

        private void dataGridView1_EnabledChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //if (DiscounttextBox.Text != "0")
            //{
            //    if (DiscounttextBox.Text != "" && TotaltextBox.Text != "")
            //    {
            //        double subtPrice = 0;
            //        double divi = double.Parse(DiscounttextBox.Text) / 100;
            //        subtPrice = double.Parse(TotaltextBox.Text) * divi;
            //        subTotaltextBox.Text = (int.Parse(TotaltextBox.Text) - subtPrice).ToString();
            //    }

            //}
            //else
            //{
            //    subTotaltextBox.Text = TotaltextBox.Text;
            //}
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // if (dataGridView1.Rows.Count > 1)

        //    for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                //     if (Room_comboBox.Text == dataGridView2.Rows[i].Cells[0].Value.ToString())
                {

                }
            }


            // DataTable dttable = tab.GetDataByTableName(Room_comboBox.Text);
            ///  DataTable dtCust = tabcust.GetDataByName(Customer_comboBox.Text);
            //  dataofsale.Insert(dateTimeforform.Value.Date, long.Parse(subTotaltextBox.Text), int.Parse(dttable.Rows[0][0].ToString()), int.Parse(dtCust.Rows[0][0].ToString()), "GENERATED");

            //   for (int i = 0; i < (dataGridView1.Rows.Count) - 1; i++)

            // DataTable di = dataofitem.GetDataByName(dataGridView1.Rows[i].Cells[0].Value.ToString());
            // data.Insert(invoiceNo, long.Parse(dataGridView1.Rows[i].Cells[2].Value.ToString()), long.Parse(dataGridView1.Rows[i].Cells[1].Value.ToString()), long.Parse(dataGridView1.Rows[i].Cells[3].Value.ToString()), long.Parse(di.Rows[0][0].ToString()));







            //for (int it = 0; it < (dataGridView1.Rows.Count) - 1; it++)
            //{
            //    GridViewClass grid = new GridViewClass();
            //    grid.itemName = dataGridView1.Rows[it].Cells[0].Value.ToString();
            //    grid.price = long.Parse(dataGridView1.Rows[it].Cells[1].Value.ToString());
            //    grid.Qty = long.Parse(dataGridView1.Rows[it].Cells[2].Value.ToString());
            //    grid.Total = long.Parse(dataGridView1.Rows[it].Cells[3].Value.ToString());
            //    gridclass.Add(grid);
            //}


        }
        private void Reportbutton_Click(object sender, EventArgs e)
        {
            MontlysaleForm sale = new MontlysaleForm(CompanyLabel.Text);
            sale.Show();
        }

        //private void SearchBarCodetextBox_TextChanged(object sender, EventArgs e)
        //{
        //    dataGridView1.Focus();
        //    using (BillingDatabaseDataSetTableAdapters.ItemTableAdapter data = new BillingDatabaseDataSetTableAdapters.ItemTableAdapter())
        //    {

        //        DataTable dt = data.GetDataByBarCode(SearchBarCodetextBox.Text);

        //        dataGridView1.Rows.Add(dt.Rows[0][1], dt.Rows[0][4], 1, dt.Rows[0][4]);
        //        for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
        //        {
        //            total = total + int.Parse(dataGridView1.Rows[i].Cells[3].Value.ToString());
        //        }

        //        DiscounttextBox.Text = "0";
        //        TotaltextBox.Text = total.ToString();
        //        subTotaltextBox.Text = total.ToString();
        //        total = 0;

        //    }
        //}

        private void button1_Click(object sender, EventArgs e)
        {
            GrapicallyReportForm sale = new GrapicallyReportForm(CompanyLabel.Text);
            sale.Show();
        }

        private void Refreshbutton_Click(object sender, EventArgs e)
        {

        }

        private void Companylabel_Click(object sender, EventArgs e)
        {

        }

        private void dateTimeforform_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button6_KeyDown(object sender, KeyEventArgs e)
        {


        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Control && e.KeyCode == Keys.P)
            {

                //   if (dataGridView1.Rows.Count > 1)
                {

                }
                List<GridViewClass> gridclass = new List<GridViewClass>();
                //for (int it = 0; it < (dataGridView1.Rows.Count) - 1; it++)
                {
                    GridViewClass grid = new GridViewClass();
                    //     grid.itemName = dataGridView1.Rows[it].Cells[0].Value.ToString();
                    //   grid.price = long.Parse(dataGridView1.Rows[it].Cells[1].Value.ToString());
                    // grid.Qty = long.Parse(dataGridView1.Rows[it].Cells[2].Value.ToString());
                    //grid.Total = long.Parse(dataGridView1.Rows[it].Cells[3].Value.ToString());
                    gridclass.Add(grid);
                }
                //   ReportForm form = new ReportForm(dateTimeforform.Text, gridclass, subTotaltextBox.Text, TotaltextBox.Text, DiscounttextBox.Text, Companylabel.Text, invoiceNo,Customer_comboBox.Text,Room_comboBox.Text);
                // form.Show();
                //   dataGridView1.Rows.Clear();
                //TotaltextBox.Clear();
                //subTotaltextBox.Clear();
                //DiscounttextBox.Clear();
                //dataGridView2.Rows.Clear();
                Form1_Load(this, null);


                //  dataGridView1_CellEndEdit(this, null);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
          // AddCustomerForm cust = new AddCustomerForm(null);
            ///cust.Show();
            //GenerateBillForm form = new GenerateBillForm();
            //form.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //if (dataGridView1.Rows.Count > 1)
            {


            //    for (int i = 0; i < dataGridView2.Rows.Count; i++)
                {
                    //  if (Room_comboBox.Text == dataGridView2.Rows[i].Cells[0].Value.ToString())
                    {
                        MessageBox.Show("Table Already Reserved");
                        goto exit;
                    }
                }
              //  int invoiceNo = 0;


            }

          //  MessageBox.Show("Bill PostPond Successfully");
            //dataGridView2.Rows.Clear();
         //   Form1_Load(this, null);
            //   dataGridView1.Rows.Clear();
         //   TotaltextBox.Clear();
          //  subTotaltextBox.Clear();
           // DiscounttextBox.Clear();
            exit:
            ;
        }

        private void button_room1_Click(object sender, EventArgs e)
        {
            using(RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(54);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,54,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 1);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(54);

                        AddCustomerForm add = new AddCustomerForm(dttable,54,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom2_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(55);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,55,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 2);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(55);

                        AddCustomerForm add = new AddCustomerForm(dttable,55,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom3_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(56);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,56,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 3);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(56);

                        AddCustomerForm add = new AddCustomerForm(dttable,56,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom4_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(57);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,57,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 4);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(57);

                        AddCustomerForm add = new AddCustomerForm(dttable,57,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom5_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(58);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 58, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 4);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(58);

                        AddCustomerForm add = new AddCustomerForm(dttable, 58, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom6_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(59);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 59, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 4);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(59);

                        AddCustomerForm add = new AddCustomerForm(dttable, 59, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom7_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(60);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 60, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 4);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(60);

                        AddCustomerForm add = new AddCustomerForm(dttable, 60, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom8_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(61);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 61, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 4);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(61);

                        AddCustomerForm add = new AddCustomerForm(dttable, 61, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom9_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(62);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 62, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 4);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(62);

                        AddCustomerForm add = new AddCustomerForm(dttable, 62, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom10_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(63);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 63, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 4);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(63);

                        AddCustomerForm add = new AddCustomerForm(dttable, 63, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom11_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(64);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 64, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 4);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(64);

                        AddCustomerForm add = new AddCustomerForm(dttable, 64, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom12_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(65);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 65, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 4);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(65);

                        AddCustomerForm add = new AddCustomerForm(dttable, 65, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom13_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(66);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 66, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 4);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(66);

                        AddCustomerForm add = new AddCustomerForm(dttable, 66, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom14_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(67);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,67,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 14);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(67);

                        AddCustomerForm add = new AddCustomerForm(dttable,67,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom15_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(68);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,68,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 15);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(68);

                        AddCustomerForm add = new AddCustomerForm(dttable,68,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom16_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(69);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,69,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(69);

                        AddCustomerForm add = new AddCustomerForm(dttable,69,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom17_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(70);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 70, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(70);

                        AddCustomerForm add = new AddCustomerForm(dttable, 70, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom18_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(71);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 71, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(71);

                        AddCustomerForm add = new AddCustomerForm(dttable, 71, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom19_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(72);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 72, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(72);

                        AddCustomerForm add = new AddCustomerForm(dttable, 72, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom20_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(73);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 73, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(73);

                        AddCustomerForm add = new AddCustomerForm(dttable, 73, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom21_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(74);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 74, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(74);

                        AddCustomerForm add = new AddCustomerForm(dttable, 74, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom22_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(75);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 75, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(75);

                        AddCustomerForm add = new AddCustomerForm(dttable, 75, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom23_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(76);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 76, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(76);

                        AddCustomerForm add = new AddCustomerForm(dttable, 76, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom24_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(77);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 77, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(77);

                        AddCustomerForm add = new AddCustomerForm(dttable, 77, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom25_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(78);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 78, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(78);

                        AddCustomerForm add = new AddCustomerForm(dttable, 78, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom26_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(79);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 79, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(79);

                        AddCustomerForm add = new AddCustomerForm(dttable, 79, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom27_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(80);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 80, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(80);

                        AddCustomerForm add = new AddCustomerForm(dttable, 80, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom28_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(81);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 81, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(81);

                        AddCustomerForm add = new AddCustomerForm(dttable, 81, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom29_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(82);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 82, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(82);

                        AddCustomerForm add = new AddCustomerForm(dttable, 82, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom30_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(83);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 83, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(83);

                        AddCustomerForm add = new AddCustomerForm(dttable, 83, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom31_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(84);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 84, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 16);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(84);

                        AddCustomerForm add = new AddCustomerForm(dttable, 84, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom32_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(85);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 85, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 33);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(85);

                        AddCustomerForm add = new AddCustomerForm(dttable, 85, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom33_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(86);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,86,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 33);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(86);

                        AddCustomerForm add = new AddCustomerForm(dttable,86,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom34_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(87);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 87, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 33);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(87);

                        AddCustomerForm add = new AddCustomerForm(dttable, 87, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom35_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(88);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,88,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 35);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(88);

                        AddCustomerForm add = new AddCustomerForm(dttable,88,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom36_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(89);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null, 89, null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 33);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(89);

                        AddCustomerForm add = new AddCustomerForm(dttable, 89, null);
                        add.Show();

                    }
                }
            }
        }
        private void buttonRoom37_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(90);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,90,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 37);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(90);

                        AddCustomerForm add = new AddCustomerForm(dttable,90,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom38_Click(object sender, EventArgs e)
        {

        }

        private void buttonRoom39_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(39);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,39,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 39);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(39);

                        AddCustomerForm add = new AddCustomerForm(dttable,39,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom40_Click(object sender, EventArgs e)
        {

        }

        private void buttonRoom41_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(41);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,41,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 41);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(41);

                        AddCustomerForm add = new AddCustomerForm(dttable,41,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom42_Click(object sender, EventArgs e)
        {

        }

        private void buttonRoom43_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(43);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,43,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 43);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(43);

                        AddCustomerForm add = new AddCustomerForm(dttable,43,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom44_Click(object sender, EventArgs e)
        {

        }

        private void buttonRoom45_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(45);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,45,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 45);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(45);

                        AddCustomerForm add = new AddCustomerForm(dttable,45,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom46_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(46);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,46,null);
                    add.Show();

                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 46);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(46);

                        AddCustomerForm add = new AddCustomerForm(dttable,46,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom47_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(47);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,47,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 47);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(47);

                        AddCustomerForm add = new AddCustomerForm(dttable,47, null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom48_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(48);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,48,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 48);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(48);

                        AddCustomerForm add = new AddCustomerForm(dttable,48,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom49_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(49);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,49,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 49);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(49);

                        AddCustomerForm add = new AddCustomerForm(dttable,49,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom50_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(50);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,50,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 50);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(50);

                        AddCustomerForm add = new AddCustomerForm(dttable,50,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom51_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(51);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,51,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 51);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(51);

                        AddCustomerForm add = new AddCustomerForm(dttable,51,null);
                        add.Show();

                    }
                }
            }
        }

        private void buttonRoom52_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
            {
                DataTable dt = roo.GetDataByRoomID(52);
                if (dt.Rows[0][2].ToString() == "Free")
                {
                    AddCustomerForm add = new AddCustomerForm(null,52,null);
                    add.Show();
                    //roo.UpdateQueryforStatus("Reserved", 50);("Reserved", 52);
                }
                else
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        DataTable dttable = reser.GetDataByRoomIDReserved(52);

                        AddCustomerForm add = new AddCustomerForm(dttable,52,null);
                        add.Show();

                    }
                }
            }
        }

        private void Refreshbutton_Click_1(object sender, EventArgs e)
        {
            Form1_Load(this, null);
        }

        private void BillReport_button_Click(object sender, EventArgs e)
        {
            PurchaseInvoiceForm pur = new PurchaseInvoiceForm(null,0);
            pur.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            BillDisplayForm bill = new BillDisplayForm();
            bill.Show();
        }

        private void Bill_button_Click(object sender, EventArgs e)
        {
            ReservationDetailForm reser = new ReservationDetailForm();
            reser.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void occupaidroom_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Bill_button_Click_1(object sender, EventArgs e)
        {
            ReservationDetailForm form = new ReservationDetailForm();
            form.Show();

        }

        private void BillReport_button_Click_1(object sender, EventArgs e)
        {
            PurchaseInvoiceForm form = new PurchaseInvoiceForm(null, 0);
            form.Show();

            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            BillDisplayForm form = new BillDisplayForm();
            form.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            SalaryForm form = new SalaryForm();
            form.Show();
        }

        private void ReservationINFObutton_Click(object sender, EventArgs e)
        {
            ReservationINFOForm re = new ReservationINFOForm();
            re.Show();
        }
    }
}