﻿namespace WindowsFormsApplication1
{
    partial class billwiseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource3 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.Searc_Invoice_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button_bill = new System.Windows.Forms.Button();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.paidClassBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.GridViewClassBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.paidClassBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewClassBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // Searc_Invoice_textBox
            // 
            this.Searc_Invoice_textBox.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.Searc_Invoice_textBox.Location = new System.Drawing.Point(89, 20);
            this.Searc_Invoice_textBox.Name = "Searc_Invoice_textBox";
            this.Searc_Invoice_textBox.Size = new System.Drawing.Size(297, 27);
            this.Searc_Invoice_textBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Invoice #";
            // 
            // button_bill
            // 
            this.button_bill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(226)))), ((int)(((byte)(118)))));
            this.button_bill.FlatAppearance.BorderSize = 0;
            this.button_bill.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_bill.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_bill.Location = new System.Drawing.Point(404, 20);
            this.button_bill.Name = "button_bill";
            this.button_bill.Size = new System.Drawing.Size(75, 27);
            this.button_bill.TabIndex = 2;
            this.button_bill.Text = "Get Result";
            this.button_bill.UseVisualStyleBackColor = false;
            this.button_bill.Click += new System.EventHandler(this.button_bill_Click);
            // 
            // reportViewer1
            // 
            reportDataSource3.Name = "DataSet1";
            reportDataSource3.Value = this.paidClassBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource3);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "WindowsFormsApplication1.Report2.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 65);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(928, 370);
            this.reportViewer1.TabIndex = 3;
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load);
            // 
            // paidClassBindingSource
            // 
            this.paidClassBindingSource.DataSource = typeof(WindowsFormsApplication1.paidClass);
            // 
            // GridViewClassBindingSource
            // 
            this.GridViewClassBindingSource.DataSource = typeof(WindowsFormsApplication1.GridViewClass);
            // 
            // billwiseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(906, 349);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.button_bill);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Searc_Invoice_textBox);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "billwiseForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "billwiseForm";
            this.Load += new System.EventHandler(this.billwiseForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.paidClassBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewClassBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Searc_Invoice_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_bill;
        private System.Windows.Forms.BindingSource paidClassBindingSource;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource GridViewClassBindingSource;
    }
}