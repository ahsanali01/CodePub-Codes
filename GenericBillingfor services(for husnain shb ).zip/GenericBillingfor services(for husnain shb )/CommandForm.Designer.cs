﻿namespace WindowsFormsApplication1
{
    partial class CommandForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Coomand_textBox = new System.Windows.Forms.TextBox();
            this.Check_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Coomand_textBox
            // 
            this.Coomand_textBox.Location = new System.Drawing.Point(62, 55);
            this.Coomand_textBox.Multiline = true;
            this.Coomand_textBox.Name = "Coomand_textBox";
            this.Coomand_textBox.Size = new System.Drawing.Size(293, 33);
            this.Coomand_textBox.TabIndex = 0;
            // 
            // Check_button
            // 
            this.Check_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(226)))), ((int)(((byte)(118)))));
            this.Check_button.FlatAppearance.BorderSize = 0;
            this.Check_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Check_button.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check_button.Location = new System.Drawing.Point(363, 55);
            this.Check_button.Name = "Check_button";
            this.Check_button.Size = new System.Drawing.Size(75, 33);
            this.Check_button.TabIndex = 1;
            this.Check_button.Text = "ENTER";
            this.Check_button.UseVisualStyleBackColor = false;
            this.Check_button.Click += new System.EventHandler(this.Check_button_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(61, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 17);
            this.label1.TabIndex = 20;
            this.label1.Text = "Command";
            // 
            // CommandForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(506, 135);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Check_button);
            this.Controls.Add(this.Coomand_textBox);
            this.MaximizeBox = false;
            this.Name = "CommandForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CommandForm";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Coomand_textBox;
        private System.Windows.Forms.Button Check_button;
        private System.Windows.Forms.Label label1;
    }
}