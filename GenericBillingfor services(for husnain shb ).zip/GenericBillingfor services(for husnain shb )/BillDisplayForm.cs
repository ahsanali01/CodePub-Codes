﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class BillDisplayForm : Form
    {
        public BillDisplayForm()
        {
            InitializeComponent();
        }

        public void BillDisplayForm_Load(object sender, EventArgs e)
        {
            GenerateBillView_list.Rows.Clear();
            using(RoomDataSetTableAdapters.purchaseInvoiceTableAdapter purchase = new RoomDataSetTableAdapters.purchaseInvoiceTableAdapter())
            {
                DataTable dt=purchase.GetData();
                for(int i=0; i < dt.Rows.Count; i++)
                {
                    GenerateBillView_list.Rows.Add(dt.Rows[i][1].ToString(), dt.Rows[i][2].ToString(), dt.Rows[i][3].ToString(), dt.Rows[i][4].ToString());
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void GenerateBillView_list_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void GenerateBillView_list_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void GenerateBillView_list_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void GenerateBillView_list_DoubleClick(object sender, EventArgs e)
        {
            if (GenerateBillView_list.CurrentRow != null)
            {
                using(RoomDataSetTableAdapters.itemListPurchaseTableAdapter itemdetail = new RoomDataSetTableAdapters.itemListPurchaseTableAdapter())
                {
                    using (RoomDataSetTableAdapters.purchaseInvoiceTableAdapter invoicedetail = new RoomDataSetTableAdapters.purchaseInvoiceTableAdapter())
                    {
                        DataTable invoiveID = invoicedetail.GetDataByinvoiceIdanddate(int.Parse(GenerateBillView_list.CurrentRow.Cells[0].Value.ToString()),DateTime.Parse(GenerateBillView_list.CurrentRow.Cells[1].Value.ToString()));
                        DataTable itemswithinvoiceID = itemdetail.GetDataByInvoiceID(int.Parse(invoiveID.Rows[0][0].ToString()));
                        PurchaseInvoiceForm pur = new PurchaseInvoiceForm(itemswithinvoiceID, int.Parse(GenerateBillView_list.CurrentRow.Cells[0].Value.ToString()));
                        pur.Show();
                    }
                }
            }
        }

        private void button_Search_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.purchaseInvoiceTableAdapter purchase = new RoomDataSetTableAdapters.purchaseInvoiceTableAdapter())
            {
                DataTable dtpurchase = purchase.GetDataById(int.Parse(Searc_Invoice_textBox.Text));
                GenerateBillView_list.Rows.Clear();
                for (int i = 0; i < dtpurchase.Rows.Count; i++)
                {
                    GenerateBillView_list.Rows.Add(dtpurchase.Rows[i][0].ToString(), dtpurchase.Rows[i][1].ToString(), dtpurchase.Rows[i][2].ToString(), dtpurchase.Rows[i][3].ToString());
                }
            }
        }

        private void BillDisplayForm_KeyDown(object sender, KeyEventArgs e)
        {
          
      
        }
    }
}
