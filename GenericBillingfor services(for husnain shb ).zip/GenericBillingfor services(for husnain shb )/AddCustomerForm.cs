﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class AddCustomerForm : Form
    {
        public  DataGridView Generate { get; set; }
        DataTable dtTable;
        public string SetValueForText1 ;
       // public string SetValuefrmdelete;
        string cHECK;
        //  DataGridView foodtable;
        //  string foodttext;
        
        int RoomID;
        int num;
        
        Random ran = new Random();
    
       
        public AddCustomerForm( DataTable dttable,int roomid,string check)
        {
            
            InitializeComponent();
            //  Food_text.Text = ItemForm.SetValueForText1;
            //   foodtable = ItemForm.gridviwData;

          hidentextBox.Text = SetValueForText1;
            this.dtTable = dttable;
            this.RoomID = roomid;
            this.cHECK = check;
        }

        private void Submit_Cust_Recoed_Click(object sender, EventArgs e)
        {
           
            if (Cnic_Txt.Text != "" && CustomerName_txt.Text != "" && richTextBox1.Text != "" && Member_txt.Text != "" && Mob_No_txt.Text != "" && Rent_txt.Text != "" && Advance_textBox.Text != "")
            {
                
                using (RoomDataSetTableAdapters.ReservationTableAdapter roo = new RoomDataSetTableAdapters.ReservationTableAdapter())
                {
                    using (RoomDataSetTableAdapters.RoomTableAdapter room = new RoomDataSetTableAdapters.RoomTableAdapter())
                    {
                        DataTable counter=roo.GetData();
                        //if (counter.Rows.Count < 20)
                        //{
                            num = ran.Next();
                            roo.Insert(long.Parse(Cnic_Txt.Text), CustomerName_txt.Text, richTextBox1.Text, long.Parse(Mob_No_txt.Text), int.Parse(Member_txt.Text), num, DateTime.Today, int.Parse(Rent_txt.Text), int.Parse(Discount_txt.Text), int.Parse(Foodtextfortotal.Text), int.Parse(Advance_textBox.Text), int.Parse(Remaining_textBox.Text), RoomID, int.Parse(other_textBox.Text), carNO_textBox.Text, int.Parse(Total_textBox.Text), "CheckedIn");
                            using (RoomDataSetTableAdapters.InvoiceTableAdapter dt = new RoomDataSetTableAdapters.InvoiceTableAdapter())
                            {


                                // foodtable=form1.Generate;
                                HiddendataGridView = Generate;

                                // DataTable name;
                                if (HiddendataGridView != null)
                                {
                                    for (int j = 0; j < HiddendataGridView.Rows.Count - 1; j++)
                                    {
                                        // name = it.GetDataByName();
                                        DataTable lastrow = roo.GetDataByReservationNo(num);
                                        dt.Insert(int.Parse(lastrow.Rows[0][0].ToString()), HiddendataGridView.Rows[j].Cells[0].Value.ToString(), int.Parse(HiddendataGridView.Rows[j].Cells[1].Value.ToString()), int.Parse(HiddendataGridView.Rows[j].Cells[2].Value.ToString()), int.Parse(HiddendataGridView.Rows[j].Cells[3].Value.ToString()));

                                    }

                                }
                            }
                            MessageBox.Show("Room Reserved");
                            room.UpdateQueryforStatus("Reserved", RoomID);
                            //if (dateTimePicker1.Value.Date == DateTime.Today)
                            //{


                            //}
                            //else
                            //{
                            //    room.UpdateQueryforStatus("Reserved", RoomID);

                            //}
                            Cnic_Txt.Text = "";
                            CustomerName_txt.Text = "";
                            Mob_No_txt.Text = "";
                            richTextBox1.Text = "";
                            Member_txt.Text = "";
                            carNO_textBox.Text = "";
                            Rent_txt.Text = "0";
                            Foodtextfortotal.Text = "0";
                            other_textBox.Text = "0";
                            Discount_txt.Text = "";
                            Advance_textBox.Text = "";
                            Remaining_textBox.Text = "";
                            Form1 form = (Form1)Application.OpenForms["Form1"];
                            form.Form1_Load(this, null);
                        //}
                        //else
                        //{
                        //    MessageBox.Show("For Full Version Contact us at 03215289975 ");
                        //}
                    }
                }
            }

        }

       public void AddCustomerForm_Load(object sender, EventArgs e)
        {
         //   other_textBox_TextChanged(this, null);
            Rent_txt.Text = "0";
            Foodtextfortotal.Text = "0";
            other_textBox.Text = "0";
            Total_textBox.Text = "0";
            
          //  Update.Enabled = false;
            if (dtTable != null)
            {
                //   AddCustomerForm.ActiveForm.Text = "Reservation Info";
                if (cHECK == "buttoncheck")
                {
                    Free_Room_button.Visible = false;
                }
                else
                {
                    Free_Room_button.Visible = true;
                }
                Update_button.Visible = true;
                Submit_Cust_Recoed.Visible = false;
                if (int.Parse(dtTable.Rows[0][10].ToString()) == 0)
                {
                    ReservationIDtextBox.Text = dtTable.Rows[0][0].ToString();
                    ReservationNotextBox.Text= dtTable.Rows[0][6].ToString();
                }
                Cnic_Txt.Text = dtTable.Rows[0][1].ToString();
                CustomerName_txt.Text= dtTable.Rows[0][2].ToString();
                Mob_No_txt.Text= dtTable.Rows[0][4].ToString();
                Member_txt.Text= dtTable.Rows[0][5].ToString();
                richTextBox1.Text= dtTable.Rows[0][3].ToString();
                carNO_textBox.Text= dtTable.Rows[0][15].ToString();
                Rent_txt.Text= dtTable.Rows[0][8].ToString();
                Foodtextfortotal.Text = dtTable.Rows[0][10].ToString();
                Discount_txt.Text= dtTable.Rows[0][9].ToString();
              
                Advance_textBox.Text= dtTable.Rows[0][11].ToString();
                Remaining_textBox.Text= dtTable.Rows[0][12].ToString();
                Total_textBox.Text= dtTable.Rows[0][16].ToString();

                other_textBox.Text = dtTable.Rows[0][14].ToString();
             //   Discount_txt_TextChanged(this, null);
            }
            else
            {
                Update_button.Visible = false;
                Submit_Cust_Recoed.Visible = true;
                Free_Room_button.Visible = false;
            }
        }

        private void Total_textBox_TextChanged(object sender, EventArgs e)
        {
            //if (Rent_txt.Text != "" && Foodtextfortotal.Text != "")
            //    Total_textBox.Text = (int.Parse(Rent_txt.Text) + int.Parse(Foodtextfortotal.Text) + int.Parse(other_textBox.Text)).ToString();
        }

        private void other_textBox_TextChanged(object sender, EventArgs e)
        {
            // ItemForm form1 = (ItemForm)Application.OpenForms["ItemForm"];
            try {

                if (Rent_txt.Text != "" && Foodtextfortotal.Text != "" && other_textBox.Text != "")
                    Total_textBox.Text = (int.Parse(Rent_txt.Text) + int.Parse(Foodtextfortotal.Text) + int.Parse(other_textBox.Text)).ToString();
            }
            catch (Exception )
            {
                MessageBox.Show("Must be number");

            }
            }

        private void Rent_txt_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Rent_txt.Text != "" && Foodtextfortotal.Text != "" && other_textBox.Text != "")
                    Total_textBox.Text = (int.Parse(Rent_txt.Text) + int.Parse(Foodtextfortotal.Text) + int.Parse(other_textBox.Text)).ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("Must be number");

            }
        }


        private void Food_text_TextChanged(object sender, EventArgs e)
        {
          

        }

        private void Discount_txt_TextChanged(object sender, EventArgs e)
        {
            try
            {

                Total_textBox.Text = (int.Parse(Rent_txt.Text) + int.Parse(Foodtextfortotal.Text) + int.Parse(other_textBox.Text)).ToString();

                //  double subPrice = 0;
                if (Discount_txt.Text != "")
                {

                    int a = int.Parse(Total_textBox.Text);
                    int b = int.Parse(Discount_txt.Text);
                    //double divi = / 100;
                    //subPrice = double.Parse(Total_textBox.Text) * divi;
                    int c = (a - b);
                    Total_textBox.Text = c.ToString();
                    c = 0;
                }
                else
                {
                    Total_textBox.Text = (int.Parse(Rent_txt.Text) + int.Parse(Foodtextfortotal.Text) + int.Parse(other_textBox.Text)).ToString();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Must be number");

            }
        }

        private void Advance_textBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Advance_textBox.Text != "")
                {
                    if (int.Parse(Advance_textBox.Text) <= int.Parse(Total_textBox.Text))
                    {
                        Remaining_textBox.Text = (int.Parse(Total_textBox.Text) - int.Parse(Advance_textBox.Text)).ToString();

                    }
                    else
                    {
                        Advance_textBox.Text = Total_textBox.Text;
                        Remaining_textBox.Text = "0";
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Must be number");

            }
        }

        private void Update_button_Click(object sender, EventArgs e)
        {
           
                using (RoomDataSetTableAdapters.ReservationTableAdapter roo = new RoomDataSetTableAdapters.ReservationTableAdapter())
                {
                    roo.UpdateQueryforReservationtable(long.Parse(Cnic_Txt.Text), CustomerName_txt.Text, richTextBox1.Text, long.Parse(Mob_No_txt.Text), int.Parse(Member_txt.Text), int.Parse(Rent_txt.Text), int.Parse(Discount_txt.Text), int.Parse(Foodtextfortotal.Text), int.Parse(Advance_textBox.Text), int.Parse(Remaining_textBox.Text), RoomID, int.Parse(other_textBox.Text), carNO_textBox.Text, int.Parse(Total_textBox.Text), int.Parse(dtTable.Rows[0][0].ToString()));
                    MessageBox.Show("Updated Successfully");
                    Cnic_Txt.Text = "";
                    CustomerName_txt.Text = "";
                    Mob_No_txt.Text = "";
                    richTextBox1.Text = "";
                    Member_txt.Text = "";
                    carNO_textBox.Text = "";
                    Rent_txt.Text = "0";
                    Foodtextfortotal.Text = "0";
                    other_textBox.Text = "0";
                    Discount_txt.Text = "";
                    Advance_textBox.Text = "";
                    Remaining_textBox.Text = "";
                }
          
                if ( ReservationIDtextBox.Text != "")
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter roo = new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        using (RoomDataSetTableAdapters.RoomTableAdapter room = new RoomDataSetTableAdapters.RoomTableAdapter())
                        {
                            using (RoomDataSetTableAdapters.InvoiceTableAdapter dt = new RoomDataSetTableAdapters.InvoiceTableAdapter())
                            {


                                // foodtable=form1.Generate;
                                HiddendataGridView = Generate;
                                for (int j = 0; j < HiddendataGridView.Rows.Count - 1; j++)
                                {
                                    // name = it.GetDataByName();
                                    DataTable lastrow = roo.GetDataByReservationNo(int.Parse(ReservationNotextBox.Text));
                                    dt.Insert(int.Parse(lastrow.Rows[0][0].ToString()), HiddendataGridView.Rows[j].Cells[0].Value.ToString(), int.Parse(HiddendataGridView.Rows[j].Cells[1].Value.ToString()), int.Parse(HiddendataGridView.Rows[j].Cells[2].Value.ToString()), int.Parse(HiddendataGridView.Rows[j].Cells[3].Value.ToString()));

                                }
                            }
                        }
                    }
                
            }
        }

        private void Free_Room_button_Click(object sender, EventArgs e)
        {
           
                string message = "Are you sure you want to free this room?";
                string title = "Free Room";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, title, buttons);
                if (result == DialogResult.Yes)
                {
                ReportForm re = new ReportForm(RoomID);
                re.Show();
                using (RoomDataSetTableAdapters.RoomTableAdapter roo = new RoomDataSetTableAdapters.RoomTableAdapter())
                {
                    using (RoomDataSetTableAdapters.ReservationTableAdapter reservcheck= new RoomDataSetTableAdapters.ReservationTableAdapter())
                    {
                        roo.UpdateQueryforStatus("Free", RoomID);
                        reservcheck.UpdateQueryOnlyForStatus("Checkedout", RoomID);
                        //    MessageBox.Show("Room Freed");

                        Cnic_Txt.Text = "";
                        CustomerName_txt.Text = "";
                        Mob_No_txt.Text = "";
                        richTextBox1.Text = "";
                        Member_txt.Text = "";
                        carNO_textBox.Text = "";
                        Rent_txt.Text = "0";
                        Foodtextfortotal.Text = "0";
                        other_textBox.Text = "0";
                        Discount_txt.Text = "";
                        Advance_textBox.Text = "";
                        Remaining_textBox.Text = "";
                        Form1 form = (Form1)Application.OpenForms["Form1"];
                        form.Form1_Load(this, null);

                    }
                }
            }
        }

        private void Print_button_Click(object sender, EventArgs e)
        {
            ReportForm repo = new ReportForm(RoomID);
            repo.Show();
        }

        private void AddItemsbutton_Click(object sender, EventArgs e)
        {
            if (dtTable == null)
            {
                ItemForm it = new ItemForm(RoomID, num, null);
                it.Show();
            }
            else
            {
                using (RoomDataSetTableAdapters.InvoiceTableAdapter i = new RoomDataSetTableAdapters.InvoiceTableAdapter())
                {
                   DataTable iteminfo= i.GetDataByReservationID(int.Parse(dtTable.Rows[0][0].ToString()));

                    ItemForm it = new ItemForm(0, 0, iteminfo);
                    it.Show();
                }
            }
        }

        private void hidentextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Foodtextfortotal_MouseClick(object sender, MouseEventArgs e)
        {
            if (SetValueForText1 != null)
            {
                //hidentextBox.Text =;
                Foodtextfortotal.Text = SetValueForText1;
                other_textBox_TextChanged(this, null);
                Advance_textBox_TextChanged(this, null);
                
            }
            //if (Foodtextfortotal != null)
            //{
            //    //hidentextBox.Text =;
            //    Foodtextfortotal.Text = SetValueForText1;
            //    other_textBox_TextChanged(this, null);
            //    Advance_textBox_TextChanged(this, null);

            //}
        }

        private void AddItemsbutton_ControlRemoved(object sender, ControlEventArgs e)
        {

        }

        private void Foodtextfortotal_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Rent_txt.Text != "" && Foodtextfortotal.Text != "" && other_textBox.Text != "")
                    Total_textBox.Text = (int.Parse(Rent_txt.Text) + int.Parse(Foodtextfortotal.Text) + int.Parse(other_textBox.Text)).ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("Must be number");

            }
        }

    }
}
