﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class ReservationDetailForm : Form
    {
        public ReservationDetailForm()
        {
            InitializeComponent();
        }

        private void ReservationDetailForm_Load(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.ReservationTableAdapter reser = new RoomDataSetTableAdapters.ReservationTableAdapter())
            {
                using (RoomDataSetTableAdapters.RoomTableAdapter reserroom = new RoomDataSetTableAdapters.RoomTableAdapter())
                {
                    DataTable dtreser = reser.GetDataByCheckedout();
                    for (int i = 0; i < dtreser.Rows.Count; i++)
                    {
                        DataTable roomNo = reserroom.GetDataByRoomID(int.Parse(dtreser.Rows[i][13].ToString()));
                        DateTime date = DateTime.Parse(dtreser.Rows[i][7].ToString());
                        string datefinal = date.ToString("dd-MM-yyyy");

                        ReservationView_list.Rows.Add(dtreser.Rows[i][6].ToString(), datefinal, roomNo.Rows[0][1].ToString(), dtreser.Rows[i][16].ToString());
                    }
                }
            }
        }

        private void ReservationView_list_DoubleClick(object sender, EventArgs e)
        {

            if (ReservationView_list.CurrentRow != null)
            {
                CommandForm form = new CommandForm(int.Parse(ReservationView_list.CurrentRow.Cells[0].Value.ToString()));
                form.Show();
            }
        }

        private void button_Search_by_Reservation_Click(object sender, EventArgs e)
        {
            using (RoomDataSetTableAdapters.ReservationTableAdapter re = new RoomDataSetTableAdapters.ReservationTableAdapter())
            {
                using (RoomDataSetTableAdapters.RoomTableAdapter reserroom = new RoomDataSetTableAdapters.RoomTableAdapter())
                {
                    DataTable dtreser = re.GetDataByCheckedout();
                    DataTable dt = re.GetDataByReservationNo(int.Parse(Searc_ReservationNo_textBox.Text));
                    DataTable roomNo = reserroom.GetDataByRoomID(int.Parse(dt.Rows[0][13].ToString()));
                    DateTime date = DateTime.Parse(dt.Rows[0][7].ToString());
                    string datefinal = date.ToString("dd-MM-yyyy");
                    ReservationView_list.Rows.Add(dt.Rows[0][6].ToString(), datefinal, roomNo.Rows[0][1].ToString(), dt.Rows[0][16].ToString());
                }
            }
        }
    }
}