﻿namespace WindowsFormsApplication1
{
    partial class AddCustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddCustomerForm));
            this.Submit_Cust_Recoed = new System.Windows.Forms.Button();
            this.Mob_No_txt = new System.Windows.Forms.TextBox();
            this.Cnic_Txt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CustomerName_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Member_txt = new System.Windows.Forms.ComboBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Discount_txt = new System.Windows.Forms.TextBox();
            this.carNO_textBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Rent_txt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Remaining_textBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Advance_textBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.other_textBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Update_button = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.Total_textBox = new System.Windows.Forms.TextBox();
            this.Free_Room_button = new System.Windows.Forms.Button();
            this.HiddendataGridView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hidentextBox = new System.Windows.Forms.TextBox();
            this.Foodtextfortotal = new System.Windows.Forms.TextBox();
            this.AddItemsbutton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ReservationIDtextBox = new System.Windows.Forms.TextBox();
            this.ReservationNotextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.HiddendataGridView)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Submit_Cust_Recoed
            // 
            this.Submit_Cust_Recoed.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Submit_Cust_Recoed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(226)))), ((int)(((byte)(118)))));
            this.Submit_Cust_Recoed.FlatAppearance.BorderSize = 0;
            this.Submit_Cust_Recoed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Submit_Cust_Recoed.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submit_Cust_Recoed.Location = new System.Drawing.Point(414, 435);
            this.Submit_Cust_Recoed.Name = "Submit_Cust_Recoed";
            this.Submit_Cust_Recoed.Size = new System.Drawing.Size(142, 36);
            this.Submit_Cust_Recoed.TabIndex = 25;
            this.Submit_Cust_Recoed.Text = "Submit";
            this.Submit_Cust_Recoed.UseVisualStyleBackColor = false;
            this.Submit_Cust_Recoed.Click += new System.EventHandler(this.Submit_Cust_Recoed_Click);
            // 
            // Mob_No_txt
            // 
            this.Mob_No_txt.AcceptsReturn = true;
            this.Mob_No_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Mob_No_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mob_No_txt.Location = new System.Drawing.Point(496, 113);
            this.Mob_No_txt.Multiline = true;
            this.Mob_No_txt.Name = "Mob_No_txt";
            this.Mob_No_txt.Size = new System.Drawing.Size(190, 33);
            this.Mob_No_txt.TabIndex = 24;
            // 
            // Cnic_Txt
            // 
            this.Cnic_Txt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Cnic_Txt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.Cnic_Txt.BackColor = System.Drawing.SystemColors.Window;
            this.Cnic_Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cnic_Txt.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.Cnic_Txt.Location = new System.Drawing.Point(63, 112);
            this.Cnic_Txt.Multiline = true;
            this.Cnic_Txt.Name = "Cnic_Txt";
            this.Cnic_Txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Cnic_Txt.Size = new System.Drawing.Size(189, 33);
            this.Cnic_Txt.TabIndex = 23;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(277, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 17);
            this.label5.TabIndex = 22;
            this.label5.Text = "Customer Name";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(493, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 17);
            this.label3.TabIndex = 21;
            this.label3.Text = "Mobile No";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(61, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 19;
            this.label1.Text = "Cnic No";
            // 
            // CustomerName_txt
            // 
            this.CustomerName_txt.AcceptsReturn = true;
            this.CustomerName_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CustomerName_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerName_txt.Location = new System.Drawing.Point(280, 112);
            this.CustomerName_txt.Multiline = true;
            this.CustomerName_txt.Name = "CustomerName_txt";
            this.CustomerName_txt.Size = new System.Drawing.Size(190, 33);
            this.CustomerName_txt.TabIndex = 30;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(711, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 17);
            this.label4.TabIndex = 29;
            this.label4.Text = "Members";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(60, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 17);
            this.label7.TabIndex = 31;
            this.label7.Text = "Address";
            // 
            // Member_txt
            // 
            this.Member_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Member_txt.BackColor = System.Drawing.Color.White;
            this.Member_txt.DisplayMember = "CategoryName";
            this.Member_txt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Member_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Member_txt.FormattingEnabled = true;
            this.Member_txt.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.Member_txt.Location = new System.Drawing.Point(714, 113);
            this.Member_txt.Name = "Member_txt";
            this.Member_txt.Size = new System.Drawing.Size(190, 33);
            this.Member_txt.TabIndex = 27;
            this.Member_txt.ValueMember = "CategoryName";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.richTextBox1.Location = new System.Drawing.Point(63, 188);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(841, 70);
            this.richTextBox1.TabIndex = 32;
            this.richTextBox1.Text = "";
            // 
            // Discount_txt
            // 
            this.Discount_txt.AcceptsReturn = true;
            this.Discount_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Discount_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Discount_txt.Location = new System.Drawing.Point(280, 368);
            this.Discount_txt.Multiline = true;
            this.Discount_txt.Name = "Discount_txt";
            this.Discount_txt.Size = new System.Drawing.Size(190, 33);
            this.Discount_txt.TabIndex = 36;
            this.Discount_txt.TextChanged += new System.EventHandler(this.Discount_txt_TextChanged);
            // 
            // carNO_textBox
            // 
            this.carNO_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.carNO_textBox.BackColor = System.Drawing.SystemColors.Window;
            this.carNO_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carNO_textBox.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.carNO_textBox.Location = new System.Drawing.Point(62, 296);
            this.carNO_textBox.Multiline = true;
            this.carNO_textBox.Name = "carNO_textBox";
            this.carNO_textBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.carNO_textBox.Size = new System.Drawing.Size(190, 33);
            this.carNO_textBox.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(279, 348);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 17);
            this.label6.TabIndex = 34;
            this.label6.Text = "Discount";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(59, 276);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 17);
            this.label8.TabIndex = 33;
            this.label8.Text = "Car No";
            // 
            // Rent_txt
            // 
            this.Rent_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Rent_txt.BackColor = System.Drawing.SystemColors.Window;
            this.Rent_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rent_txt.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.Rent_txt.Location = new System.Drawing.Point(280, 296);
            this.Rent_txt.Multiline = true;
            this.Rent_txt.Name = "Rent_txt";
            this.Rent_txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Rent_txt.Size = new System.Drawing.Size(190, 33);
            this.Rent_txt.TabIndex = 39;
            this.Rent_txt.TextChanged += new System.EventHandler(this.Rent_txt_TextChanged);
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(494, 276);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 17);
            this.label9.TabIndex = 38;
            this.label9.Text = "Food Bill";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(277, 276);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(36, 17);
            this.label10.TabIndex = 37;
            this.label10.Text = "Rent";
            // 
            // Remaining_textBox
            // 
            this.Remaining_textBox.AcceptsReturn = true;
            this.Remaining_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Remaining_textBox.BackColor = System.Drawing.Color.White;
            this.Remaining_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remaining_textBox.Location = new System.Drawing.Point(714, 368);
            this.Remaining_textBox.Multiline = true;
            this.Remaining_textBox.Name = "Remaining_textBox";
            this.Remaining_textBox.ReadOnly = true;
            this.Remaining_textBox.Size = new System.Drawing.Size(190, 33);
            this.Remaining_textBox.TabIndex = 44;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(713, 348);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 17);
            this.label11.TabIndex = 43;
            this.label11.Text = "Remaining Payment";
            // 
            // Advance_textBox
            // 
            this.Advance_textBox.AcceptsReturn = true;
            this.Advance_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Advance_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Advance_textBox.Location = new System.Drawing.Point(497, 368);
            this.Advance_textBox.Multiline = true;
            this.Advance_textBox.Name = "Advance_textBox";
            this.Advance_textBox.Size = new System.Drawing.Size(190, 33);
            this.Advance_textBox.TabIndex = 42;
            this.Advance_textBox.TextChanged += new System.EventHandler(this.Advance_textBox_TextChanged);
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(495, 348);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(118, 17);
            this.label12.TabIndex = 41;
            this.label12.Text = "Advance Payment";
            // 
            // other_textBox
            // 
            this.other_textBox.AcceptsReturn = true;
            this.other_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.other_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.other_textBox.Location = new System.Drawing.Point(714, 296);
            this.other_textBox.Multiline = true;
            this.other_textBox.Name = "other_textBox";
            this.other_textBox.Size = new System.Drawing.Size(190, 33);
            this.other_textBox.TabIndex = 45;
            this.other_textBox.TextChanged += new System.EventHandler(this.other_textBox_TextChanged);
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(711, 276);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 17);
            this.label13.TabIndex = 46;
            this.label13.Text = "Other Charges";
            // 
            // Update_button
            // 
            this.Update_button.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Update_button.BackColor = System.Drawing.Color.White;
            this.Update_button.FlatAppearance.BorderSize = 0;
            this.Update_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Update_button.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update_button.Location = new System.Drawing.Point(328, 435);
            this.Update_button.Name = "Update_button";
            this.Update_button.Size = new System.Drawing.Size(142, 36);
            this.Update_button.TabIndex = 47;
            this.Update_button.Text = "Update";
            this.Update_button.UseVisualStyleBackColor = false;
            this.Update_button.Click += new System.EventHandler(this.Update_button_Click);
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(60, 348);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(92, 17);
            this.label14.TabIndex = 49;
            this.label14.Text = "Total Charges";
            // 
            // Total_textBox
            // 
            this.Total_textBox.AcceptsReturn = true;
            this.Total_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Total_textBox.BackColor = System.Drawing.Color.White;
            this.Total_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total_textBox.Location = new System.Drawing.Point(62, 368);
            this.Total_textBox.Multiline = true;
            this.Total_textBox.Name = "Total_textBox";
            this.Total_textBox.ReadOnly = true;
            this.Total_textBox.Size = new System.Drawing.Size(190, 33);
            this.Total_textBox.TabIndex = 48;
            this.Total_textBox.TextChanged += new System.EventHandler(this.Total_textBox_TextChanged);
            // 
            // Free_Room_button
            // 
            this.Free_Room_button.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Free_Room_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(226)))), ((int)(((byte)(118)))));
            this.Free_Room_button.FlatAppearance.BorderSize = 0;
            this.Free_Room_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Free_Room_button.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Free_Room_button.Location = new System.Drawing.Point(498, 435);
            this.Free_Room_button.Name = "Free_Room_button";
            this.Free_Room_button.Size = new System.Drawing.Size(142, 36);
            this.Free_Room_button.TabIndex = 50;
            this.Free_Room_button.Text = "Checkout";
            this.Free_Room_button.UseVisualStyleBackColor = false;
            this.Free_Room_button.Click += new System.EventHandler(this.Free_Room_button_Click);
            // 
            // HiddendataGridView
            // 
            this.HiddendataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.HiddendataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.HiddendataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.HiddendataGridView.Location = new System.Drawing.Point(12, 2);
            this.HiddendataGridView.Name = "HiddendataGridView";
            this.HiddendataGridView.Size = new System.Drawing.Size(85, 58);
            this.HiddendataGridView.TabIndex = 53;
            this.HiddendataGridView.Visible = false;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Item Name";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Price";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Quantity";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Total";
            this.Column4.Name = "Column4";
            // 
            // hidentextBox
            // 
            this.hidentextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hidentextBox.Location = new System.Drawing.Point(125, 12);
            this.hidentextBox.Name = "hidentextBox";
            this.hidentextBox.Size = new System.Drawing.Size(100, 20);
            this.hidentextBox.TabIndex = 54;
            this.hidentextBox.Visible = false;
            this.hidentextBox.TextChanged += new System.EventHandler(this.hidentextBox_TextChanged);
            // 
            // Foodtextfortotal
            // 
            this.Foodtextfortotal.AcceptsReturn = true;
            this.Foodtextfortotal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Foodtextfortotal.BackColor = System.Drawing.Color.White;
            this.Foodtextfortotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Foodtextfortotal.Location = new System.Drawing.Point(496, 296);
            this.Foodtextfortotal.Multiline = true;
            this.Foodtextfortotal.Name = "Foodtextfortotal";
            this.Foodtextfortotal.ReadOnly = true;
            this.Foodtextfortotal.Size = new System.Drawing.Size(190, 33);
            this.Foodtextfortotal.TabIndex = 55;
            this.Foodtextfortotal.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Foodtextfortotal_MouseClick);
            this.Foodtextfortotal.TextChanged += new System.EventHandler(this.Foodtextfortotal_TextChanged);
            // 
            // AddItemsbutton
            // 
            this.AddItemsbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddItemsbutton.BackColor = System.Drawing.Color.White;
            this.AddItemsbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("AddItemsbutton.BackgroundImage")));
            this.AddItemsbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.AddItemsbutton.FlatAppearance.BorderSize = 0;
            this.AddItemsbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddItemsbutton.Location = new System.Drawing.Point(658, 302);
            this.AddItemsbutton.Name = "AddItemsbutton";
            this.AddItemsbutton.Size = new System.Drawing.Size(20, 20);
            this.AddItemsbutton.TabIndex = 52;
            this.AddItemsbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.AddItemsbutton.UseVisualStyleBackColor = false;
            this.AddItemsbutton.Click += new System.EventHandler(this.AddItemsbutton_Click);
            this.AddItemsbutton.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.AddItemsbutton_ControlRemoved);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(36)))), ((int)(((byte)(37)))));
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(-1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(969, 66);
            this.panel1.TabIndex = 56;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(132)))), ((int)(((byte)(33)))));
            this.panel3.Location = new System.Drawing.Point(180, 33);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 1);
            this.panel3.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(132)))), ((int)(((byte)(33)))));
            this.panel2.Location = new System.Drawing.Point(565, 34);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 1);
            this.panel2.TabIndex = 2;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(36)))), ((int)(((byte)(37)))));
            this.label15.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(389, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(169, 25);
            this.label15.TabIndex = 1;
            this.label15.Text = "Reservation Form";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "label2";
            // 
            // ReservationIDtextBox
            // 
            this.ReservationIDtextBox.Location = new System.Drawing.Point(778, 452);
            this.ReservationIDtextBox.Name = "ReservationIDtextBox";
            this.ReservationIDtextBox.Size = new System.Drawing.Size(100, 20);
            this.ReservationIDtextBox.TabIndex = 57;
            this.ReservationIDtextBox.Visible = false;
            // 
            // ReservationNotextBox
            // 
            this.ReservationNotextBox.Location = new System.Drawing.Point(716, 488);
            this.ReservationNotextBox.Name = "ReservationNotextBox";
            this.ReservationNotextBox.Size = new System.Drawing.Size(100, 20);
            this.ReservationNotextBox.TabIndex = 58;
            this.ReservationNotextBox.Visible = false;
            // 
            // AddCustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(968, 520);
            this.Controls.Add(this.ReservationNotextBox);
            this.Controls.Add(this.ReservationIDtextBox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.AddItemsbutton);
            this.Controls.Add(this.Foodtextfortotal);
            this.Controls.Add(this.hidentextBox);
            this.Controls.Add(this.HiddendataGridView);
            this.Controls.Add(this.Free_Room_button);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.Total_textBox);
            this.Controls.Add(this.Update_button);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.other_textBox);
            this.Controls.Add(this.Remaining_textBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Advance_textBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Rent_txt);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Discount_txt);
            this.Controls.Add(this.carNO_textBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.CustomerName_txt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Member_txt);
            this.Controls.Add(this.Submit_Cust_Recoed);
            this.Controls.Add(this.Mob_No_txt);
            this.Controls.Add(this.Cnic_Txt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "AddCustomerForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Reservation";
            this.Load += new System.EventHandler(this.AddCustomerForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.HiddendataGridView)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Submit_Cust_Recoed;
        private System.Windows.Forms.TextBox Mob_No_txt;
        private System.Windows.Forms.TextBox Cnic_Txt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CustomerName_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Member_txt;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox Discount_txt;
        private System.Windows.Forms.TextBox carNO_textBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Rent_txt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Remaining_textBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Advance_textBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox other_textBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button Update_button;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox Total_textBox;
        private System.Windows.Forms.Button Free_Room_button;
        private System.Windows.Forms.Button AddItemsbutton;
        private System.Windows.Forms.DataGridView HiddendataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.TextBox hidentextBox;
        private System.Windows.Forms.TextBox Foodtextfortotal;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox ReservationIDtextBox;
        private System.Windows.Forms.TextBox ReservationNotextBox;
    }
}