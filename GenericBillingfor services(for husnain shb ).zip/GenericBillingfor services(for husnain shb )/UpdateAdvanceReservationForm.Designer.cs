﻿namespace WindowsFormsApplication1
{
    partial class UpdateAdvanceReservationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.hidentextBox = new System.Windows.Forms.TextBox();
            this.HiddendataGridView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Update_button = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.CO = new System.Windows.Forms.TextBox();
            this.Advance = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Rent = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.PhoneNo = new System.Windows.Forms.TextBox();
            this.RoomNo = new System.Windows.Forms.TextBox();
            this.CustomerName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HiddendataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(36)))), ((int)(((byte)(37)))));
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(754, 66);
            this.panel1.TabIndex = 89;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(132)))), ((int)(((byte)(33)))));
            this.panel3.Location = new System.Drawing.Point(48, 32);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 1);
            this.panel3.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(132)))), ((int)(((byte)(33)))));
            this.panel2.Location = new System.Drawing.Point(503, 33);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 1);
            this.panel2.TabIndex = 2;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(36)))), ((int)(((byte)(37)))));
            this.label15.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(257, 17);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(237, 25);
            this.label15.TabIndex = 1;
            this.label15.Text = "Edit Advance Reservation";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "label2";
            // 
            // hidentextBox
            // 
            this.hidentextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hidentextBox.Location = new System.Drawing.Point(126, 11);
            this.hidentextBox.Name = "hidentextBox";
            this.hidentextBox.Size = new System.Drawing.Size(0, 20);
            this.hidentextBox.TabIndex = 87;
            this.hidentextBox.Visible = false;
            // 
            // HiddendataGridView
            // 
            this.HiddendataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.HiddendataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.HiddendataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.HiddendataGridView.Location = new System.Drawing.Point(13, 1);
            this.HiddendataGridView.Name = "HiddendataGridView";
            this.HiddendataGridView.Size = new System.Drawing.Size(0, 0);
            this.HiddendataGridView.TabIndex = 86;
            this.HiddendataGridView.Visible = false;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Item Name";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Price";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Quantity";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Total";
            this.Column4.Name = "Column4";
            // 
            // Update_button
            // 
            this.Update_button.BackColor = System.Drawing.Color.White;
            this.Update_button.FlatAppearance.BorderSize = 0;
            this.Update_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Update_button.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update_button.Location = new System.Drawing.Point(308, 256);
            this.Update_button.Name = "Update_button";
            this.Update_button.Size = new System.Drawing.Size(142, 36);
            this.Update_button.TabIndex = 81;
            this.Update_button.Text = "Update";
            this.Update_button.UseVisualStyleBackColor = false;
            this.Update_button.Click += new System.EventHandler(this.Update_button_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(495, 170);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 17);
            this.label13.TabIndex = 80;
            this.label13.Text = "C/O";
            // 
            // CO
            // 
            this.CO.AcceptsReturn = true;
            this.CO.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CO.Location = new System.Drawing.Point(497, 190);
            this.CO.Multiline = true;
            this.CO.Name = "CO";
            this.CO.Size = new System.Drawing.Size(190, 33);
            this.CO.TabIndex = 79;
            // 
            // Advance
            // 
            this.Advance.BackColor = System.Drawing.SystemColors.Window;
            this.Advance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Advance.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.Advance.Location = new System.Drawing.Point(281, 190);
            this.Advance.Multiline = true;
            this.Advance.Name = "Advance";
            this.Advance.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Advance.Size = new System.Drawing.Size(190, 33);
            this.Advance.TabIndex = 74;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(278, 170);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 17);
            this.label10.TabIndex = 72;
            this.label10.Text = "Advance Payment";
            // 
            // Rent
            // 
            this.Rent.BackColor = System.Drawing.SystemColors.Window;
            this.Rent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rent.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.Rent.Location = new System.Drawing.Point(63, 190);
            this.Rent.Multiline = true;
            this.Rent.Name = "Rent";
            this.Rent.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Rent.Size = new System.Drawing.Size(190, 33);
            this.Rent.TabIndex = 70;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(60, 170);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 17);
            this.label8.TabIndex = 68;
            this.label8.Text = "Rent";
            // 
            // PhoneNo
            // 
            this.PhoneNo.AcceptsReturn = true;
            this.PhoneNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNo.Location = new System.Drawing.Point(281, 111);
            this.PhoneNo.Multiline = true;
            this.PhoneNo.Name = "PhoneNo";
            this.PhoneNo.Size = new System.Drawing.Size(190, 33);
            this.PhoneNo.TabIndex = 65;
            // 
            // RoomNo
            // 
            this.RoomNo.AcceptsReturn = true;
            this.RoomNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomNo.Location = new System.Drawing.Point(497, 112);
            this.RoomNo.Multiline = true;
            this.RoomNo.Name = "RoomNo";
            this.RoomNo.Size = new System.Drawing.Size(190, 33);
            this.RoomNo.TabIndex = 61;
            // 
            // CustomerName
            // 
            this.CustomerName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.CustomerName.BackColor = System.Drawing.SystemColors.Window;
            this.CustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerName.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.CustomerName.Location = new System.Drawing.Point(64, 111);
            this.CustomerName.Multiline = true;
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CustomerName.Size = new System.Drawing.Size(189, 33);
            this.CustomerName.TabIndex = 60;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(278, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 17);
            this.label5.TabIndex = 59;
            this.label5.Text = "Phone No";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(494, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 17);
            this.label3.TabIndex = 58;
            this.label3.Text = "Room No";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 17);
            this.label1.TabIndex = 57;
            this.label1.Text = "Guest Name";
            // 
            // UpdateAdvanceReservationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 321);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.hidentextBox);
            this.Controls.Add(this.HiddendataGridView);
            this.Controls.Add(this.Update_button);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.CO);
            this.Controls.Add(this.Advance);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Rent);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.PhoneNo);
            this.Controls.Add(this.RoomNo);
            this.Controls.Add(this.CustomerName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "UpdateAdvanceReservationForm";
            this.Text = "UpdateAdvanceReservationForm";
            this.Load += new System.EventHandler(this.UpdateAdvanceReservationForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HiddendataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox hidentextBox;
        private System.Windows.Forms.DataGridView HiddendataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Button Update_button;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox CO;
        private System.Windows.Forms.TextBox Advance;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Rent;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox PhoneNo;
        private System.Windows.Forms.TextBox RoomNo;
        private System.Windows.Forms.TextBox CustomerName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
    }
}