﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
  public class GridViewforpaidClass
    {
        public string forpaiditemName { get; set; }
        public long forpaidprice { get; set; }
        public long forpaidQty { get; set; }

        public long forpaidTotal { get; set; }
    }
}
