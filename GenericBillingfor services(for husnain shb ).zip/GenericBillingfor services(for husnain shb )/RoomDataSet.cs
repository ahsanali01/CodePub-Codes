﻿namespace WindowsFormsApplication1
{


    partial class RoomDataSet
    {
        partial class DataTable1DataTable
        {
        }
    }
}
