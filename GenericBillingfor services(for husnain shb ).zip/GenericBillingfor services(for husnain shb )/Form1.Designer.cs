﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.ReservationINFObutton = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.Bill_button = new System.Windows.Forms.Button();
            this.BillReport_button = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Reportbutton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonRoom1 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.roomBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.servicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.billingDatabaseDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel4 = new System.Windows.Forms.Panel();
            this.CompanyLabel = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Freeroom = new System.Windows.Forms.Label();
            this.Totalroom = new System.Windows.Forms.Label();
            this.occupaidroom = new System.Windows.Forms.Label();
            this.button_room1 = new System.Windows.Forms.Button();
            this.buttonRoom2 = new System.Windows.Forms.Button();
            this.buttonRoom3 = new System.Windows.Forms.Button();
            this.buttonRoom4 = new System.Windows.Forms.Button();
            this.buttonRoom5 = new System.Windows.Forms.Button();
            this.buttonRoom6 = new System.Windows.Forms.Button();
            this.buttonRoom7 = new System.Windows.Forms.Button();
            this.buttonRoom8 = new System.Windows.Forms.Button();
            this.buttonRoom9 = new System.Windows.Forms.Button();
            this.buttonRoom10 = new System.Windows.Forms.Button();
            this.buttonRoom11 = new System.Windows.Forms.Button();
            this.buttonRoom12 = new System.Windows.Forms.Button();
            this.buttonRoom13 = new System.Windows.Forms.Button();
            this.buttonRoom14 = new System.Windows.Forms.Button();
            this.buttonRoom15 = new System.Windows.Forms.Button();
            this.buttonRoom16 = new System.Windows.Forms.Button();
            this.buttonRoom17 = new System.Windows.Forms.Button();
            this.buttonRoom18 = new System.Windows.Forms.Button();
            this.buttonRoom19 = new System.Windows.Forms.Button();
            this.buttonRoom20 = new System.Windows.Forms.Button();
            this.buttonRoom21 = new System.Windows.Forms.Button();
            this.buttonRoom22 = new System.Windows.Forms.Button();
            this.buttonRoom23 = new System.Windows.Forms.Button();
            this.buttonRoom24 = new System.Windows.Forms.Button();
            this.buttonRoom25 = new System.Windows.Forms.Button();
            this.buttonRoom26 = new System.Windows.Forms.Button();
            this.buttonRoom27 = new System.Windows.Forms.Button();
            this.buttonRoom28 = new System.Windows.Forms.Button();
            this.buttonRoom29 = new System.Windows.Forms.Button();
            this.buttonRoom30 = new System.Windows.Forms.Button();
            this.buttonRoom31 = new System.Windows.Forms.Button();
            this.buttonRoom32 = new System.Windows.Forms.Button();
            this.buttonRoom33 = new System.Windows.Forms.Button();
            this.buttonRoom34 = new System.Windows.Forms.Button();
            this.buttonRoom35 = new System.Windows.Forms.Button();
            this.buttonRoom36 = new System.Windows.Forms.Button();
            this.buttonRoom37 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingDatabaseDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(57)))), ((int)(((byte)(58)))));
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.ReservationINFObutton);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.Bill_button);
            this.panel1.Controls.Add(this.BillReport_button);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.Reportbutton);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Name = "panel1";
            // 
            // pictureBox8
            // 
            resources.ApplyResources(this.pictureBox8, "pictureBox8");
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.TabStop = false;
            // 
            // ReservationINFObutton
            // 
            this.ReservationINFObutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(57)))), ((int)(((byte)(58)))));
            this.ReservationINFObutton.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.ReservationINFObutton.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.ReservationINFObutton, "ReservationINFObutton");
            this.ReservationINFObutton.ForeColor = System.Drawing.Color.White;
            this.ReservationINFObutton.Name = "ReservationINFObutton";
            this.ReservationINFObutton.UseVisualStyleBackColor = false;
            this.ReservationINFObutton.Click += new System.EventHandler(this.ReservationINFObutton_Click);
            // 
            // pictureBox7
            // 
            resources.ApplyResources(this.pictureBox7, "pictureBox7");
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.TabStop = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(57)))), ((int)(((byte)(58)))));
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.button3, "button3");
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Name = "button3";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            // 
            // pictureBox6
            // 
            resources.ApplyResources(this.pictureBox6, "pictureBox6");
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            resources.ApplyResources(this.pictureBox5, "pictureBox5");
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            resources.ApplyResources(this.pictureBox4, "pictureBox4");
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            resources.ApplyResources(this.pictureBox3, "pictureBox3");
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(31)))), ((int)(((byte)(61)))));
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(57)))), ((int)(((byte)(58)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.button2, "button2");
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Bill_button
            // 
            this.Bill_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(57)))), ((int)(((byte)(58)))));
            this.Bill_button.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Bill_button.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.Bill_button, "Bill_button");
            this.Bill_button.ForeColor = System.Drawing.Color.White;
            this.Bill_button.Name = "Bill_button";
            this.Bill_button.UseVisualStyleBackColor = false;
            this.Bill_button.Click += new System.EventHandler(this.Bill_button_Click_1);
            // 
            // BillReport_button
            // 
            this.BillReport_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(57)))), ((int)(((byte)(58)))));
            this.BillReport_button.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.BillReport_button.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.BillReport_button, "BillReport_button");
            this.BillReport_button.ForeColor = System.Drawing.Color.White;
            this.BillReport_button.Name = "BillReport_button";
            this.BillReport_button.UseVisualStyleBackColor = false;
            this.BillReport_button.Click += new System.EventHandler(this.BillReport_button_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(57)))), ((int)(((byte)(58)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button1.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.button1, "button1");
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Reportbutton
            // 
            this.Reportbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(57)))), ((int)(((byte)(58)))));
            this.Reportbutton.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Reportbutton.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.Reportbutton, "Reportbutton");
            this.Reportbutton.ForeColor = System.Drawing.Color.White;
            this.Reportbutton.Name = "Reportbutton";
            this.Reportbutton.UseVisualStyleBackColor = false;
            this.Reportbutton.Click += new System.EventHandler(this.Reportbutton_Click);
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // dateTimePicker1
            // 
            resources.ApplyResources(this.dateTimePicker1, "dateTimePicker1");
            this.dateTimePicker1.Name = "dateTimePicker1";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Name = "label11";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Name = "label10";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(132)))), ((int)(((byte)(33)))));
            this.label8.Name = "label8";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(132)))), ((int)(((byte)(33)))));
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(132)))), ((int)(((byte)(33)))));
            this.label1.Name = "label1";
            // 
            // buttonRoom1
            // 
            this.buttonRoom1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.buttonRoom1, "buttonRoom1");
            this.buttonRoom1.Name = "buttonRoom1";
            this.buttonRoom1.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button6, "button6");
            this.button6.Name = "button6";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button7, "button7");
            this.button7.Name = "button7";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button8, "button8");
            this.button8.Name = "button8";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button9, "button9");
            this.button9.Name = "button9";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button10, "button10");
            this.button10.Name = "button10";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button11, "button11");
            this.button11.Name = "button11";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button12, "button12");
            this.button12.Name = "button12";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button13, "button13");
            this.button13.Name = "button13";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button14, "button14");
            this.button14.Name = "button14";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button15, "button15");
            this.button15.Name = "button15";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button16, "button16");
            this.button16.Name = "button16";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // roomBindingSource
            // 
            this.roomBindingSource.DataMember = "Room";
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            // 
            // servicesBindingSource
            // 
            this.servicesBindingSource.DataMember = "Services";
            // 
            // tableBindingSource1
            // 
            this.tableBindingSource1.DataSource = this.billingDatabaseDataSetBindingSource;
            // 
            // itemBindingSource1
            // 
            this.itemBindingSource1.DataMember = "Item";
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(194)))), ((int)(((byte)(50)))));
            this.panel4.Controls.Add(this.CompanyLabel);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Name = "panel4";
            // 
            // CompanyLabel
            // 
            resources.ApplyResources(this.CompanyLabel, "CompanyLabel");
            this.CompanyLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(194)))), ((int)(((byte)(50)))));
            this.CompanyLabel.ForeColor = System.Drawing.Color.White;
            this.CompanyLabel.Name = "CompanyLabel";
            this.CompanyLabel.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(38)))), ((int)(((byte)(41)))));
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.Freeroom);
            this.panel3.Controls.Add(this.Totalroom);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.occupaidroom);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.dateTimePicker1);
            this.panel3.Name = "panel3";
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(210)))), ((int)(((byte)(127)))));
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(125)))), ((int)(((byte)(144)))));
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Name = "panel6";
            // 
            // Freeroom
            // 
            resources.ApplyResources(this.Freeroom, "Freeroom");
            this.Freeroom.ForeColor = System.Drawing.Color.White;
            this.Freeroom.Name = "Freeroom";
            // 
            // Totalroom
            // 
            resources.ApplyResources(this.Totalroom, "Totalroom");
            this.Totalroom.ForeColor = System.Drawing.Color.White;
            this.Totalroom.Name = "Totalroom";
            // 
            // occupaidroom
            // 
            resources.ApplyResources(this.occupaidroom, "occupaidroom");
            this.occupaidroom.ForeColor = System.Drawing.Color.White;
            this.occupaidroom.Name = "occupaidroom";
            this.occupaidroom.Click += new System.EventHandler(this.occupaidroom_Click);
            // 
            // button_room1
            // 
            resources.ApplyResources(this.button_room1, "button_room1");
            this.button_room1.BackColor = System.Drawing.Color.White;
            this.button_room1.FlatAppearance.BorderSize = 0;
            this.button_room1.ForeColor = System.Drawing.Color.White;
            this.button_room1.Name = "button_room1";
            this.button_room1.UseVisualStyleBackColor = false;
            this.button_room1.Click += new System.EventHandler(this.button_room1_Click);
            // 
            // buttonRoom2
            // 
            resources.ApplyResources(this.buttonRoom2, "buttonRoom2");
            this.buttonRoom2.BackColor = System.Drawing.Color.White;
            this.buttonRoom2.FlatAppearance.BorderSize = 0;
            this.buttonRoom2.ForeColor = System.Drawing.Color.White;
            this.buttonRoom2.Name = "buttonRoom2";
            this.buttonRoom2.UseVisualStyleBackColor = false;
            this.buttonRoom2.Click += new System.EventHandler(this.buttonRoom2_Click);
            // 
            // buttonRoom3
            // 
            resources.ApplyResources(this.buttonRoom3, "buttonRoom3");
            this.buttonRoom3.BackColor = System.Drawing.Color.White;
            this.buttonRoom3.FlatAppearance.BorderSize = 0;
            this.buttonRoom3.ForeColor = System.Drawing.Color.White;
            this.buttonRoom3.Name = "buttonRoom3";
            this.buttonRoom3.UseVisualStyleBackColor = false;
            this.buttonRoom3.Click += new System.EventHandler(this.buttonRoom3_Click);
            // 
            // buttonRoom4
            // 
            resources.ApplyResources(this.buttonRoom4, "buttonRoom4");
            this.buttonRoom4.BackColor = System.Drawing.Color.White;
            this.buttonRoom4.FlatAppearance.BorderSize = 0;
            this.buttonRoom4.ForeColor = System.Drawing.Color.White;
            this.buttonRoom4.Name = "buttonRoom4";
            this.buttonRoom4.UseVisualStyleBackColor = false;
            this.buttonRoom4.Click += new System.EventHandler(this.buttonRoom4_Click);
            // 
            // buttonRoom5
            // 
            resources.ApplyResources(this.buttonRoom5, "buttonRoom5");
            this.buttonRoom5.BackColor = System.Drawing.Color.White;
            this.buttonRoom5.FlatAppearance.BorderSize = 0;
            this.buttonRoom5.ForeColor = System.Drawing.Color.White;
            this.buttonRoom5.Name = "buttonRoom5";
            this.buttonRoom5.UseVisualStyleBackColor = false;
            this.buttonRoom5.Click += new System.EventHandler(this.buttonRoom5_Click);
            // 
            // buttonRoom6
            // 
            resources.ApplyResources(this.buttonRoom6, "buttonRoom6");
            this.buttonRoom6.BackColor = System.Drawing.Color.White;
            this.buttonRoom6.FlatAppearance.BorderSize = 0;
            this.buttonRoom6.ForeColor = System.Drawing.Color.White;
            this.buttonRoom6.Name = "buttonRoom6";
            this.buttonRoom6.UseVisualStyleBackColor = false;
            this.buttonRoom6.Click += new System.EventHandler(this.buttonRoom6_Click);
            // 
            // buttonRoom7
            // 
            resources.ApplyResources(this.buttonRoom7, "buttonRoom7");
            this.buttonRoom7.BackColor = System.Drawing.Color.White;
            this.buttonRoom7.FlatAppearance.BorderSize = 0;
            this.buttonRoom7.ForeColor = System.Drawing.Color.White;
            this.buttonRoom7.Name = "buttonRoom7";
            this.buttonRoom7.UseVisualStyleBackColor = false;
            this.buttonRoom7.Click += new System.EventHandler(this.buttonRoom7_Click);
            // 
            // buttonRoom8
            // 
            resources.ApplyResources(this.buttonRoom8, "buttonRoom8");
            this.buttonRoom8.BackColor = System.Drawing.Color.White;
            this.buttonRoom8.FlatAppearance.BorderSize = 0;
            this.buttonRoom8.ForeColor = System.Drawing.Color.White;
            this.buttonRoom8.Name = "buttonRoom8";
            this.buttonRoom8.UseVisualStyleBackColor = false;
            this.buttonRoom8.Click += new System.EventHandler(this.buttonRoom8_Click);
            // 
            // buttonRoom9
            // 
            resources.ApplyResources(this.buttonRoom9, "buttonRoom9");
            this.buttonRoom9.BackColor = System.Drawing.Color.White;
            this.buttonRoom9.FlatAppearance.BorderSize = 0;
            this.buttonRoom9.ForeColor = System.Drawing.Color.White;
            this.buttonRoom9.Name = "buttonRoom9";
            this.buttonRoom9.UseVisualStyleBackColor = false;
            this.buttonRoom9.Click += new System.EventHandler(this.buttonRoom9_Click);
            // 
            // buttonRoom10
            // 
            resources.ApplyResources(this.buttonRoom10, "buttonRoom10");
            this.buttonRoom10.BackColor = System.Drawing.Color.White;
            this.buttonRoom10.FlatAppearance.BorderSize = 0;
            this.buttonRoom10.ForeColor = System.Drawing.Color.White;
            this.buttonRoom10.Name = "buttonRoom10";
            this.buttonRoom10.UseVisualStyleBackColor = false;
            this.buttonRoom10.Click += new System.EventHandler(this.buttonRoom10_Click);
            // 
            // buttonRoom11
            // 
            resources.ApplyResources(this.buttonRoom11, "buttonRoom11");
            this.buttonRoom11.BackColor = System.Drawing.Color.White;
            this.buttonRoom11.FlatAppearance.BorderSize = 0;
            this.buttonRoom11.ForeColor = System.Drawing.Color.White;
            this.buttonRoom11.Name = "buttonRoom11";
            this.buttonRoom11.UseVisualStyleBackColor = false;
            this.buttonRoom11.Click += new System.EventHandler(this.buttonRoom11_Click);
            // 
            // buttonRoom12
            // 
            resources.ApplyResources(this.buttonRoom12, "buttonRoom12");
            this.buttonRoom12.BackColor = System.Drawing.Color.White;
            this.buttonRoom12.FlatAppearance.BorderSize = 0;
            this.buttonRoom12.ForeColor = System.Drawing.Color.White;
            this.buttonRoom12.Name = "buttonRoom12";
            this.buttonRoom12.UseVisualStyleBackColor = false;
            this.buttonRoom12.Click += new System.EventHandler(this.buttonRoom12_Click);
            // 
            // buttonRoom13
            // 
            resources.ApplyResources(this.buttonRoom13, "buttonRoom13");
            this.buttonRoom13.BackColor = System.Drawing.Color.White;
            this.buttonRoom13.FlatAppearance.BorderSize = 0;
            this.buttonRoom13.ForeColor = System.Drawing.Color.White;
            this.buttonRoom13.Name = "buttonRoom13";
            this.buttonRoom13.UseVisualStyleBackColor = false;
            this.buttonRoom13.Click += new System.EventHandler(this.buttonRoom13_Click);
            // 
            // buttonRoom14
            // 
            resources.ApplyResources(this.buttonRoom14, "buttonRoom14");
            this.buttonRoom14.BackColor = System.Drawing.Color.White;
            this.buttonRoom14.FlatAppearance.BorderSize = 0;
            this.buttonRoom14.ForeColor = System.Drawing.Color.White;
            this.buttonRoom14.Name = "buttonRoom14";
            this.buttonRoom14.UseVisualStyleBackColor = false;
            this.buttonRoom14.Click += new System.EventHandler(this.buttonRoom14_Click);
            // 
            // buttonRoom15
            // 
            resources.ApplyResources(this.buttonRoom15, "buttonRoom15");
            this.buttonRoom15.BackColor = System.Drawing.Color.White;
            this.buttonRoom15.FlatAppearance.BorderSize = 0;
            this.buttonRoom15.ForeColor = System.Drawing.Color.White;
            this.buttonRoom15.Name = "buttonRoom15";
            this.buttonRoom15.UseVisualStyleBackColor = false;
            this.buttonRoom15.Click += new System.EventHandler(this.buttonRoom15_Click);
            // 
            // buttonRoom16
            // 
            resources.ApplyResources(this.buttonRoom16, "buttonRoom16");
            this.buttonRoom16.BackColor = System.Drawing.Color.White;
            this.buttonRoom16.FlatAppearance.BorderSize = 0;
            this.buttonRoom16.ForeColor = System.Drawing.Color.White;
            this.buttonRoom16.Name = "buttonRoom16";
            this.buttonRoom16.UseVisualStyleBackColor = false;
            this.buttonRoom16.Click += new System.EventHandler(this.buttonRoom16_Click);
            // 
            // buttonRoom17
            // 
            resources.ApplyResources(this.buttonRoom17, "buttonRoom17");
            this.buttonRoom17.BackColor = System.Drawing.Color.White;
            this.buttonRoom17.FlatAppearance.BorderSize = 0;
            this.buttonRoom17.ForeColor = System.Drawing.Color.White;
            this.buttonRoom17.Name = "buttonRoom17";
            this.buttonRoom17.UseVisualStyleBackColor = false;
            this.buttonRoom17.Click += new System.EventHandler(this.buttonRoom17_Click);
            // 
            // buttonRoom18
            // 
            resources.ApplyResources(this.buttonRoom18, "buttonRoom18");
            this.buttonRoom18.BackColor = System.Drawing.Color.White;
            this.buttonRoom18.FlatAppearance.BorderSize = 0;
            this.buttonRoom18.ForeColor = System.Drawing.Color.White;
            this.buttonRoom18.Name = "buttonRoom18";
            this.buttonRoom18.UseVisualStyleBackColor = false;
            this.buttonRoom18.Click += new System.EventHandler(this.buttonRoom18_Click);
            // 
            // buttonRoom19
            // 
            resources.ApplyResources(this.buttonRoom19, "buttonRoom19");
            this.buttonRoom19.BackColor = System.Drawing.Color.White;
            this.buttonRoom19.FlatAppearance.BorderSize = 0;
            this.buttonRoom19.ForeColor = System.Drawing.Color.White;
            this.buttonRoom19.Name = "buttonRoom19";
            this.buttonRoom19.UseVisualStyleBackColor = false;
            this.buttonRoom19.Click += new System.EventHandler(this.buttonRoom19_Click);
            // 
            // buttonRoom20
            // 
            resources.ApplyResources(this.buttonRoom20, "buttonRoom20");
            this.buttonRoom20.BackColor = System.Drawing.Color.White;
            this.buttonRoom20.FlatAppearance.BorderSize = 0;
            this.buttonRoom20.ForeColor = System.Drawing.Color.White;
            this.buttonRoom20.Name = "buttonRoom20";
            this.buttonRoom20.UseVisualStyleBackColor = false;
            this.buttonRoom20.Click += new System.EventHandler(this.buttonRoom20_Click);
            // 
            // buttonRoom21
            // 
            resources.ApplyResources(this.buttonRoom21, "buttonRoom21");
            this.buttonRoom21.BackColor = System.Drawing.Color.White;
            this.buttonRoom21.FlatAppearance.BorderSize = 0;
            this.buttonRoom21.ForeColor = System.Drawing.Color.White;
            this.buttonRoom21.Name = "buttonRoom21";
            this.buttonRoom21.UseVisualStyleBackColor = false;
            this.buttonRoom21.Click += new System.EventHandler(this.buttonRoom21_Click);
            // 
            // buttonRoom22
            // 
            resources.ApplyResources(this.buttonRoom22, "buttonRoom22");
            this.buttonRoom22.BackColor = System.Drawing.Color.White;
            this.buttonRoom22.FlatAppearance.BorderSize = 0;
            this.buttonRoom22.ForeColor = System.Drawing.Color.White;
            this.buttonRoom22.Name = "buttonRoom22";
            this.buttonRoom22.UseVisualStyleBackColor = false;
            this.buttonRoom22.Click += new System.EventHandler(this.buttonRoom22_Click);
            // 
            // buttonRoom23
            // 
            resources.ApplyResources(this.buttonRoom23, "buttonRoom23");
            this.buttonRoom23.BackColor = System.Drawing.Color.White;
            this.buttonRoom23.FlatAppearance.BorderSize = 0;
            this.buttonRoom23.ForeColor = System.Drawing.Color.White;
            this.buttonRoom23.Name = "buttonRoom23";
            this.buttonRoom23.UseVisualStyleBackColor = false;
            this.buttonRoom23.Click += new System.EventHandler(this.buttonRoom23_Click);
            // 
            // buttonRoom24
            // 
            resources.ApplyResources(this.buttonRoom24, "buttonRoom24");
            this.buttonRoom24.BackColor = System.Drawing.Color.White;
            this.buttonRoom24.FlatAppearance.BorderSize = 0;
            this.buttonRoom24.ForeColor = System.Drawing.Color.White;
            this.buttonRoom24.Name = "buttonRoom24";
            this.buttonRoom24.UseVisualStyleBackColor = false;
            this.buttonRoom24.Click += new System.EventHandler(this.buttonRoom24_Click);
            // 
            // buttonRoom25
            // 
            resources.ApplyResources(this.buttonRoom25, "buttonRoom25");
            this.buttonRoom25.BackColor = System.Drawing.Color.White;
            this.buttonRoom25.FlatAppearance.BorderSize = 0;
            this.buttonRoom25.ForeColor = System.Drawing.Color.White;
            this.buttonRoom25.Name = "buttonRoom25";
            this.buttonRoom25.UseVisualStyleBackColor = false;
            this.buttonRoom25.Click += new System.EventHandler(this.buttonRoom25_Click);
            // 
            // buttonRoom26
            // 
            resources.ApplyResources(this.buttonRoom26, "buttonRoom26");
            this.buttonRoom26.BackColor = System.Drawing.Color.White;
            this.buttonRoom26.FlatAppearance.BorderSize = 0;
            this.buttonRoom26.ForeColor = System.Drawing.Color.White;
            this.buttonRoom26.Name = "buttonRoom26";
            this.buttonRoom26.UseVisualStyleBackColor = false;
            this.buttonRoom26.Click += new System.EventHandler(this.buttonRoom26_Click);
            // 
            // buttonRoom27
            // 
            resources.ApplyResources(this.buttonRoom27, "buttonRoom27");
            this.buttonRoom27.BackColor = System.Drawing.Color.White;
            this.buttonRoom27.FlatAppearance.BorderSize = 0;
            this.buttonRoom27.ForeColor = System.Drawing.Color.White;
            this.buttonRoom27.Name = "buttonRoom27";
            this.buttonRoom27.UseVisualStyleBackColor = false;
            this.buttonRoom27.Click += new System.EventHandler(this.buttonRoom27_Click);
            // 
            // buttonRoom28
            // 
            resources.ApplyResources(this.buttonRoom28, "buttonRoom28");
            this.buttonRoom28.BackColor = System.Drawing.Color.White;
            this.buttonRoom28.FlatAppearance.BorderSize = 0;
            this.buttonRoom28.ForeColor = System.Drawing.Color.White;
            this.buttonRoom28.Name = "buttonRoom28";
            this.buttonRoom28.UseVisualStyleBackColor = false;
            this.buttonRoom28.Click += new System.EventHandler(this.buttonRoom28_Click);
            // 
            // buttonRoom29
            // 
            resources.ApplyResources(this.buttonRoom29, "buttonRoom29");
            this.buttonRoom29.BackColor = System.Drawing.Color.White;
            this.buttonRoom29.FlatAppearance.BorderSize = 0;
            this.buttonRoom29.ForeColor = System.Drawing.Color.White;
            this.buttonRoom29.Name = "buttonRoom29";
            this.buttonRoom29.UseVisualStyleBackColor = false;
            this.buttonRoom29.Click += new System.EventHandler(this.buttonRoom29_Click);
            // 
            // buttonRoom30
            // 
            resources.ApplyResources(this.buttonRoom30, "buttonRoom30");
            this.buttonRoom30.BackColor = System.Drawing.Color.White;
            this.buttonRoom30.FlatAppearance.BorderSize = 0;
            this.buttonRoom30.ForeColor = System.Drawing.Color.White;
            this.buttonRoom30.Name = "buttonRoom30";
            this.buttonRoom30.UseVisualStyleBackColor = false;
            this.buttonRoom30.Click += new System.EventHandler(this.buttonRoom30_Click);
            // 
            // buttonRoom31
            // 
            resources.ApplyResources(this.buttonRoom31, "buttonRoom31");
            this.buttonRoom31.BackColor = System.Drawing.Color.White;
            this.buttonRoom31.FlatAppearance.BorderSize = 0;
            this.buttonRoom31.ForeColor = System.Drawing.Color.White;
            this.buttonRoom31.Name = "buttonRoom31";
            this.buttonRoom31.UseVisualStyleBackColor = false;
            this.buttonRoom31.Click += new System.EventHandler(this.buttonRoom31_Click);
            // 
            // buttonRoom32
            // 
            resources.ApplyResources(this.buttonRoom32, "buttonRoom32");
            this.buttonRoom32.BackColor = System.Drawing.Color.White;
            this.buttonRoom32.FlatAppearance.BorderSize = 0;
            this.buttonRoom32.ForeColor = System.Drawing.Color.White;
            this.buttonRoom32.Name = "buttonRoom32";
            this.buttonRoom32.UseVisualStyleBackColor = false;
            this.buttonRoom32.Click += new System.EventHandler(this.buttonRoom32_Click);
            // 
            // buttonRoom33
            // 
            resources.ApplyResources(this.buttonRoom33, "buttonRoom33");
            this.buttonRoom33.BackColor = System.Drawing.Color.White;
            this.buttonRoom33.FlatAppearance.BorderSize = 0;
            this.buttonRoom33.ForeColor = System.Drawing.Color.White;
            this.buttonRoom33.Name = "buttonRoom33";
            this.buttonRoom33.UseVisualStyleBackColor = false;
            this.buttonRoom33.Click += new System.EventHandler(this.buttonRoom33_Click);
            // 
            // buttonRoom34
            // 
            resources.ApplyResources(this.buttonRoom34, "buttonRoom34");
            this.buttonRoom34.BackColor = System.Drawing.Color.White;
            this.buttonRoom34.FlatAppearance.BorderSize = 0;
            this.buttonRoom34.ForeColor = System.Drawing.Color.White;
            this.buttonRoom34.Name = "buttonRoom34";
            this.buttonRoom34.UseVisualStyleBackColor = false;
            this.buttonRoom34.Click += new System.EventHandler(this.buttonRoom34_Click);
            // 
            // buttonRoom35
            // 
            resources.ApplyResources(this.buttonRoom35, "buttonRoom35");
            this.buttonRoom35.BackColor = System.Drawing.Color.White;
            this.buttonRoom35.FlatAppearance.BorderSize = 0;
            this.buttonRoom35.ForeColor = System.Drawing.Color.White;
            this.buttonRoom35.Name = "buttonRoom35";
            this.buttonRoom35.UseVisualStyleBackColor = false;
            this.buttonRoom35.Click += new System.EventHandler(this.buttonRoom35_Click);
            // 
            // buttonRoom36
            // 
            resources.ApplyResources(this.buttonRoom36, "buttonRoom36");
            this.buttonRoom36.BackColor = System.Drawing.Color.White;
            this.buttonRoom36.FlatAppearance.BorderSize = 0;
            this.buttonRoom36.ForeColor = System.Drawing.Color.White;
            this.buttonRoom36.Name = "buttonRoom36";
            this.buttonRoom36.UseVisualStyleBackColor = false;
            this.buttonRoom36.Click += new System.EventHandler(this.buttonRoom36_Click);
            // 
            // buttonRoom37
            // 
            resources.ApplyResources(this.buttonRoom37, "buttonRoom37");
            this.buttonRoom37.BackColor = System.Drawing.Color.White;
            this.buttonRoom37.FlatAppearance.BorderSize = 0;
            this.buttonRoom37.ForeColor = System.Drawing.Color.White;
            this.buttonRoom37.Name = "buttonRoom37";
            this.buttonRoom37.UseVisualStyleBackColor = false;
            this.buttonRoom37.Click += new System.EventHandler(this.buttonRoom37_Click);
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Name = "panel2";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.button_room1);
            this.panel8.Controls.Add(this.buttonRoom2);
            this.panel8.Controls.Add(this.buttonRoom3);
            this.panel8.Controls.Add(this.buttonRoom4);
            this.panel8.Controls.Add(this.buttonRoom37);
            this.panel8.Controls.Add(this.buttonRoom5);
            this.panel8.Controls.Add(this.buttonRoom6);
            this.panel8.Controls.Add(this.buttonRoom36);
            this.panel8.Controls.Add(this.buttonRoom7);
            this.panel8.Controls.Add(this.buttonRoom8);
            this.panel8.Controls.Add(this.buttonRoom35);
            this.panel8.Controls.Add(this.buttonRoom9);
            this.panel8.Controls.Add(this.buttonRoom10);
            this.panel8.Controls.Add(this.buttonRoom34);
            this.panel8.Controls.Add(this.buttonRoom11);
            this.panel8.Controls.Add(this.buttonRoom12);
            this.panel8.Controls.Add(this.buttonRoom33);
            this.panel8.Controls.Add(this.buttonRoom13);
            this.panel8.Controls.Add(this.buttonRoom14);
            this.panel8.Controls.Add(this.buttonRoom32);
            this.panel8.Controls.Add(this.buttonRoom15);
            this.panel8.Controls.Add(this.buttonRoom31);
            this.panel8.Controls.Add(this.buttonRoom16);
            this.panel8.Controls.Add(this.buttonRoom30);
            this.panel8.Controls.Add(this.buttonRoom17);
            this.panel8.Controls.Add(this.buttonRoom29);
            this.panel8.Controls.Add(this.buttonRoom18);
            this.panel8.Controls.Add(this.buttonRoom28);
            this.panel8.Controls.Add(this.buttonRoom19);
            this.panel8.Controls.Add(this.buttonRoom27);
            this.panel8.Controls.Add(this.buttonRoom20);
            this.panel8.Controls.Add(this.buttonRoom26);
            this.panel8.Controls.Add(this.buttonRoom21);
            this.panel8.Controls.Add(this.buttonRoom25);
            this.panel8.Controls.Add(this.buttonRoom22);
            this.panel8.Controls.Add(this.buttonRoom24);
            this.panel8.Controls.Add(this.buttonRoom23);
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.Name = "panel8";
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IsMdiContainer = true;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingDatabaseDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Reportbutton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button1;
    //    private BillingDatabaseDataSet1 billingDatabaseDataSet1;
        private System.Windows.Forms.BindingSource itemBindingSource1;
        private System.Windows.Forms.BindingSource tableBindingSource;
    //    private BillingDatabaseDataSet4TableAdapters.TableTableAdapter tableTableAdapter;
        private System.Windows.Forms.BindingSource billingDatabaseDataSetBindingSource;
        private System.Windows.Forms.BindingSource tableBindingSource1;
        private System.Windows.Forms.Button BillReport_button;
        private System.Windows.Forms.Button Bill_button;
        private System.Windows.Forms.BindingSource roomBindingSource;
        private System.Windows.Forms.BindingSource servicesBindingSource;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
  //      private WindowsFormsApplication1.DataSet1 dataSet1;
        //private WindowsFormsApplication1.BillingDatabaseDataSet4 billingDatabaseDataSet4;
        //private WindowsFormsApplication1.BillingDatabaseDataSet billingDatabaseDataSet;
        //private WindowsFormsApplication1.BillingDatabaseDataSetTableAdapters.RoomTableAdapter tableTableAdapter1;
        //private WindowsFormsApplication1.BillingDatabaseDataSet8 billingDatabaseDataSet8;
        //private WindowsFormsApplication1.BillingDatabaseDataSet8TableAdapters.RoomTableAdapter roomTableAdapter;
        //private WindowsFormsApplication1.BillingDatabaseDataSet9 billingDatabaseDataSet9;
        //private WindowsFormsApplication1.BillingDatabaseDataSet9TableAdapters.ServicesTableAdapter servicesTableAdapter;
        //private WindowsFormsApplication1.BillingDatabaseDataSet10 billingDatabaseDataSet10;
        //private WindowsFormsApplication1.BillingDatabaseDataSet10TableAdapters.CustomerTableAdapter customerTableAdapter;
        private System.Windows.Forms.Button buttonRoom1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label CompanyLabel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label Freeroom;
        private System.Windows.Forms.Label Totalroom;
        private System.Windows.Forms.Label occupaidroom;
        private System.Windows.Forms.Button button_room1;
        private System.Windows.Forms.Button buttonRoom2;
        private System.Windows.Forms.Button buttonRoom3;
        private System.Windows.Forms.Button buttonRoom4;
        private System.Windows.Forms.Button buttonRoom13;
        private System.Windows.Forms.Button buttonRoom5;
        private System.Windows.Forms.Button buttonRoom6;
        private System.Windows.Forms.Button buttonRoom7;
        private System.Windows.Forms.Button buttonRoom8;
        private System.Windows.Forms.Button buttonRoom9;
        private System.Windows.Forms.Button buttonRoom10;
        private System.Windows.Forms.Button buttonRoom11;
        private System.Windows.Forms.Button buttonRoom12;
        private System.Windows.Forms.Button buttonRoom14;
        private System.Windows.Forms.Button buttonRoom15;
        private System.Windows.Forms.Button buttonRoom16;
        private System.Windows.Forms.Button buttonRoom17;
        private System.Windows.Forms.Button buttonRoom18;
        private System.Windows.Forms.Button buttonRoom19;
        private System.Windows.Forms.Button buttonRoom20;
        private System.Windows.Forms.Button buttonRoom21;
        private System.Windows.Forms.Button buttonRoom22;
        private System.Windows.Forms.Button buttonRoom23;
        private System.Windows.Forms.Button buttonRoom24;
        private System.Windows.Forms.Button buttonRoom25;
        private System.Windows.Forms.Button buttonRoom26;
        private System.Windows.Forms.Button buttonRoom27;
        private System.Windows.Forms.Button buttonRoom28;
        private System.Windows.Forms.Button buttonRoom29;
        private System.Windows.Forms.Button buttonRoom30;
        private System.Windows.Forms.Button buttonRoom31;
        private System.Windows.Forms.Button buttonRoom32;
        private System.Windows.Forms.Button buttonRoom33;
        private System.Windows.Forms.Button buttonRoom34;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button buttonRoom35;
        private System.Windows.Forms.Button buttonRoom36;
        private System.Windows.Forms.Button buttonRoom37;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Button ReservationINFObutton;
    }
}

