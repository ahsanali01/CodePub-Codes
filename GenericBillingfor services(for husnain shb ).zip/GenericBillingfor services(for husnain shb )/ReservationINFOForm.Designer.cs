﻿namespace WindowsFormsApplication1
{
    partial class ReservationINFOForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dateTimePickerforback = new System.Windows.Forms.DateTimePicker();
            this.Reseult_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TodateTime = new System.Windows.Forms.DateTimePicker();
            this.FromdateTime = new System.Windows.Forms.DateTimePicker();
            this.ReservationView_list = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.hidentextBox = new System.Windows.Forms.TextBox();
            this.HiddendataGridView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Free_Room_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ReservationView_list)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HiddendataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePickerforback
            // 
            this.dateTimePickerforback.Location = new System.Drawing.Point(736, 84);
            this.dateTimePickerforback.Name = "dateTimePickerforback";
            this.dateTimePickerforback.Size = new System.Drawing.Size(203, 20);
            this.dateTimePickerforback.TabIndex = 113;
            // 
            // Reseult_button
            // 
            this.Reseult_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(226)))), ((int)(((byte)(118)))));
            this.Reseult_button.FlatAppearance.BorderSize = 0;
            this.Reseult_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Reseult_button.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reseult_button.Location = new System.Drawing.Point(594, 84);
            this.Reseult_button.Name = "Reseult_button";
            this.Reseult_button.Size = new System.Drawing.Size(75, 23);
            this.Reseult_button.TabIndex = 110;
            this.Reseult_button.Text = "Get Result";
            this.Reseult_button.UseVisualStyleBackColor = false;
            this.Reseult_button.Click += new System.EventHandler(this.Reseult_button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(310, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 17);
            this.label1.TabIndex = 109;
            this.label1.Text = "To:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(18, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 17);
            this.label3.TabIndex = 108;
            this.label3.Text = "From:";
            // 
            // TodateTime
            // 
            this.TodateTime.CustomFormat = "yyyy-MM-dd";
            this.TodateTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.TodateTime.ImeMode = System.Windows.Forms.ImeMode.On;
            this.TodateTime.Location = new System.Drawing.Point(345, 85);
            this.TodateTime.Name = "TodateTime";
            this.TodateTime.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TodateTime.Size = new System.Drawing.Size(200, 20);
            this.TodateTime.TabIndex = 107;
            this.TodateTime.Value = new System.DateTime(2021, 2, 2, 0, 29, 54, 0);
            // 
            // FromdateTime
            // 
            this.FromdateTime.CustomFormat = "";
            this.FromdateTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.FromdateTime.Location = new System.Drawing.Point(73, 85);
            this.FromdateTime.Name = "FromdateTime";
            this.FromdateTime.Size = new System.Drawing.Size(200, 20);
            this.FromdateTime.TabIndex = 106;
            this.FromdateTime.Value = new System.DateTime(2021, 2, 2, 0, 30, 52, 0);
            // 
            // ReservationView_list
            // 
            this.ReservationView_list.AllowUserToDeleteRows = false;
            this.ReservationView_list.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ReservationView_list.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ReservationView_list.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ReservationView_list.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ReservationView_list.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Column5,
            this.dataGridViewTextBoxColumn2,
            this.Column6,
            this.dataGridViewTextBoxColumn3,
            this.Column7});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ReservationView_list.DefaultCellStyle = dataGridViewCellStyle2;
            this.ReservationView_list.Location = new System.Drawing.Point(-1, 127);
            this.ReservationView_list.Name = "ReservationView_list";
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(226)))), ((int)(((byte)(118)))));
            this.ReservationView_list.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.ReservationView_list.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ReservationView_list.Size = new System.Drawing.Size(970, 243);
            this.ReservationView_list.TabIndex = 105;
            this.ReservationView_list.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ReservationView_list_CellDoubleClick);
            this.ReservationView_list.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.ReservationView_list_CellEndEdit);
            this.ReservationView_list.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.ReservationView_list_UserAddedRow);
            this.ReservationView_list.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ReservationView_list_KeyDown);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Guest Name";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Phone No";
            this.Column5.Name = "Column5";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Room No";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Rent";
            this.Column6.Name = "Column6";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Advance ";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "C/O";
            this.Column7.Name = "Column7";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(36)))), ((int)(((byte)(37)))));
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(970, 66);
            this.panel1.TabIndex = 104;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(132)))), ((int)(((byte)(33)))));
            this.panel3.Location = new System.Drawing.Point(178, 33);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 1);
            this.panel3.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(132)))), ((int)(((byte)(33)))));
            this.panel2.Location = new System.Drawing.Point(589, 34);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 1);
            this.panel2.TabIndex = 2;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(36)))), ((int)(((byte)(37)))));
            this.label15.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(385, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(198, 25);
            this.label15.TabIndex = 1;
            this.label15.Text = "Advance Reservation";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "label2";
            // 
            // hidentextBox
            // 
            this.hidentextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hidentextBox.Location = new System.Drawing.Point(125, 11);
            this.hidentextBox.Name = "hidentextBox";
            this.hidentextBox.Size = new System.Drawing.Size(100, 20);
            this.hidentextBox.TabIndex = 103;
            this.hidentextBox.Visible = false;
            // 
            // HiddendataGridView
            // 
            this.HiddendataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.HiddendataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.HiddendataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.HiddendataGridView.Location = new System.Drawing.Point(12, 1);
            this.HiddendataGridView.Name = "HiddendataGridView";
            this.HiddendataGridView.Size = new System.Drawing.Size(85, 0);
            this.HiddendataGridView.TabIndex = 102;
            this.HiddendataGridView.Visible = false;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Item Name";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Price";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Quantity";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Total";
            this.Column4.Name = "Column4";
            // 
            // Free_Room_button
            // 
            this.Free_Room_button.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Free_Room_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(226)))), ((int)(((byte)(118)))));
            this.Free_Room_button.FlatAppearance.BorderSize = 0;
            this.Free_Room_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Free_Room_button.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Free_Room_button.Location = new System.Drawing.Point(20, 398);
            this.Free_Room_button.Name = "Free_Room_button";
            this.Free_Room_button.Size = new System.Drawing.Size(142, 36);
            this.Free_Room_button.TabIndex = 115;
            this.Free_Room_button.Text = "Refresh";
            this.Free_Room_button.UseVisualStyleBackColor = false;
            this.Free_Room_button.Click += new System.EventHandler(this.Free_Room_button_Click);
            // 
            // ReservationINFOForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(968, 459);
            this.Controls.Add(this.Free_Room_button);
            this.Controls.Add(this.dateTimePickerforback);
            this.Controls.Add(this.Reseult_button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TodateTime);
            this.Controls.Add(this.FromdateTime);
            this.Controls.Add(this.ReservationView_list);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.hidentextBox);
            this.Controls.Add(this.HiddendataGridView);
            this.Name = "ReservationINFOForm";
            this.Text = "ReservationINFOForm";
            this.Load += new System.EventHandler(this.ReservationINFOForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ReservationView_list)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HiddendataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dateTimePickerforback;
        private System.Windows.Forms.Button Reseult_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker TodateTime;
        private System.Windows.Forms.DateTimePicker FromdateTime;
        private System.Windows.Forms.DataGridView ReservationView_list;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox hidentextBox;
        private System.Windows.Forms.DataGridView HiddendataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.Button Free_Room_button;
    }
}